package com.yourname.udharhisab.ui.settings

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import androidx.lifecycle.lifecycleScope
import com.google.android.gms.ads.MobileAds
import com.yourname.udharhisab.R
import com.yourname.udharhisab.databinding.ActivitySettingsBinding
import com.yourname.udharhisab.utils.JsonBackupManager
import kotlinx.coroutines.launch

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding

    // প্রদর্শনের নাম (নিজ নিজ ভাষার লিপিতে) -> BCP-47 ভাষা কোড
    private val supportedLanguages = linkedMapOf(
        "English" to "en",
        "বাংলা" to "bn",
        "हिन्दी" to "hi",
        "தமிழ்" to "ta",
        "తెలుగు" to "te",
        "मराठी" to "mr",
        "ગુજરાતી" to "gu",
        "ਪੰਜਾਬੀ" to "pa",
        "മലയാളം" to "ml",
        "ಕನ್ನಡ" to "kn",
        "ଓଡ଼ିଆ" to "or",
        "অসমীয়া" to "as"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        setupLanguageSelector()
        setupBackupRestore()
        setupAbout()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = getString(R.string.nav_settings)
        binding.toolbar.setNavigationOnClickListener { finish() }
    }

    private fun setupLanguageSelector() {
        val displayNames = supportedLanguages.keys.toTypedArray()
        val adapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, displayNames)
        binding.dropdownLanguage.setAdapter(adapter)

        // বর্তমানে যে ভাষা প্রয়োগ করা আছে সেটা ড্রপডাউনে দেখানো
        val currentTag = AppCompatDelegate.getApplicationLocales().toLanguageTags()
            .substringBefore(",").substringBefore("-")
        val currentDisplayName = supportedLanguages.entries
            .firstOrNull { it.value == currentTag }?.key
            ?: displayNames.first() // কিছু সেট করা না থাকলে ডিফল্ট English
        binding.dropdownLanguage.setText(currentDisplayName, false)

        binding.dropdownLanguage.setOnItemClickListener { _, _, position, _ ->
            val selectedName = displayNames[position]
            val languageCode = supportedLanguages[selectedName] ?: return@setOnItemClickListener
            val localeList = LocaleListCompat.forLanguageTags(languageCode)
            AppCompatDelegate.setApplicationLocales(localeList)
            // AppCompatDelegate নিজে থেকেই সব Activity রিক্রিয়েট করবে নতুন ভাষা প্রয়োগ করতে
        }
    }

    private fun setupBackupRestore() {
        binding.btnBackup.setOnClickListener {
            lifecycleScope.launch {
                try {
                    val file = JsonBackupManager.exportToJson(this@SettingsActivity)
                    Toast.makeText(
                        this@SettingsActivity,
                        getString(R.string.backup_saved_named, file.name),
                        Toast.LENGTH_LONG
                    ).show()
                } catch (e: Exception) {
                    Toast.makeText(
                        this@SettingsActivity,
                        getString(R.string.backup_failed_reason, e.message ?: ""),
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }

        binding.btnRestore.setOnClickListener {
            // Show file picker dialog
            Toast.makeText(this, getString(R.string.restore_coming_soon), Toast.LENGTH_SHORT).show()
        }
    }

    private fun setupAbout() {
        binding.btnPrivacyPolicy.setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://your-website.com/privacy"))
            startActivity(intent)
        }

        binding.btnRateApp.setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW,
                Uri.parse("https://play.google.com/store/apps/details?id=${packageName}"))
            startActivity(intent)
        }

        binding.btnShareApp.setOnClickListener {
            val shareText = "${getString(R.string.share_app_text)}\n\n" +
                    "https://play.google.com/store/apps/details?id=${packageName}"
            val intent = Intent(Intent.ACTION_SEND)
            intent.type = "text/plain"
            intent.putExtra(Intent.EXTRA_TEXT, shareText)
            startActivity(Intent.createChooser(intent, getString(R.string.share)))
        }
    }
}
