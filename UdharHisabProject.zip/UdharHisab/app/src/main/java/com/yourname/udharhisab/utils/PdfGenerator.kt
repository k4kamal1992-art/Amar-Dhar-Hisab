package com.yourname.udharhisab.utils

import android.content.Context
import android.os.Environment
import com.itextpdf.io.font.PdfEncodings
import com.itextpdf.kernel.font.PdfFont
import com.itextpdf.kernel.font.PdfFontFactory
import com.itextpdf.kernel.pdf.PdfDocument
import com.itextpdf.kernel.pdf.PdfWriter
import com.itextpdf.layout.Document
import com.itextpdf.layout.element.Paragraph
import com.itextpdf.layout.element.Table
import com.itextpdf.layout.properties.UnitValue
import com.yourname.udharhisab.data.model.Shop
import com.yourname.udharhisab.data.model.Transaction
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * দোকানের লেনদেনের PDF রিপোর্ট তৈরি করে — বাংলা ফন্ট (Hind Siliguri) এম্বেড করা থাকে,
 * তাই যেকোনো ডিভাইস/PDF ভিউয়ারে বাংলা লেখা সঠিকভাবে দেখা যাবে।
 */
object PdfGenerator {

    /**
     * assets থেকে ফন্ট পড়ে iText-এর জন্য এম্বেডেবল PdfFont তৈরি করে।
     * IDENTITY_H এনকোডিং ব্যবহার করা হয় যাতে বাংলা ইউনিকোড গ্লিফ সঠিকভাবে রেন্ডার হয়।
     */
    private fun loadFont(context: Context, assetPath: String): PdfFont {
        val bytes = context.assets.open(assetPath).use { it.readBytes() }
        return PdfFontFactory.createFont(
            bytes,
            PdfEncodings.IDENTITY_H,
            PdfFontFactory.EmbeddingStrategy.FORCE_EMBEDDED
        )
    }

    suspend fun generateShopReport(
        context: Context,
        shop: Shop,
        transactions: List<Transaction>
    ): File = withContext(Dispatchers.IO) {
        val downloadsDir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
            ?: context.filesDir
        val safeShopName = shop.name.replace(" ", "_")
        val file = File(downloadsDir, "amar_dhar_hisab_${safeShopName}.pdf")

        val regularFont = loadFont(context, "fonts/hind_siliguri_regular.ttf")
        val boldFont = loadFont(context, "fonts/hind_siliguri_bold.ttf")
        val semiBoldFont = loadFont(context, "fonts/hind_siliguri_semibold.ttf")

        val writer = PdfWriter(file)
        val pdf = PdfDocument(writer)
        val document = Document(pdf)
        document.setFont(regularFont)

        // শিরোনাম
        document.add(
            Paragraph("আমার ধার হিসাব")
                .setFont(boldFont)
                .setFontSize(22f)
        )
        document.add(
            Paragraph("দোকান: ${shop.name}")
                .setFont(semiBoldFont)
                .setFontSize(14f)
        )
        if (shop.ownerName.isNotBlank()) {
            document.add(Paragraph("মালিক: ${shop.ownerName}").setFont(regularFont).setFontSize(12f))
        }
        if (shop.phone.isNotBlank()) {
            document.add(Paragraph("ফোন: ${shop.phone}").setFont(regularFont).setFontSize(12f))
        }
        document.add(
            Paragraph("রিপোর্টের তারিখ: ${DateUtils.formatFull(System.currentTimeMillis())}")
                .setFont(regularFont)
                .setFontSize(11f)
        )
        document.add(Paragraph(" "))

        // লেনদেনের টেবিল
        val table = Table(UnitValue.createPercentArray(floatArrayOf(3f, 2f, 2f, 3f))).useAllAvailableWidth()

        listOf("তারিখ", "ধরন", "পরিমাণ", "বিবরণ").forEach { header ->
            table.addHeaderCell(
                Paragraph(header).setFont(semiBoldFont).setFontSize(11f)
            )
        }

        var totalCredit = 0.0
        var totalPayment = 0.0
        val openingBalance = 0.0 // ভবিষ্যতে opening balance ফিচার যোগ হলে এখানে বসবে

        transactions.sortedBy { it.date }.forEach { t ->
            val typeLabel = if (t.type == Constants.TYPE_CREDIT) "ধার" else "পরিশোধ"
            table.addCell(Paragraph(DateUtils.formatDate(t.date)).setFont(regularFont).setFontSize(10f))
            table.addCell(Paragraph(typeLabel).setFont(regularFont).setFontSize(10f))
            table.addCell(Paragraph(NumberFormatUtils.formatAmount(t.amount)).setFont(regularFont).setFontSize(10f))

            val detail = if (t.productName.isNotBlank()) {
                "${t.productName} (${t.quantity} ${t.unit})"
            } else {
                t.note
            }
            table.addCell(Paragraph(detail).setFont(regularFont).setFontSize(10f))

            if (t.type == Constants.TYPE_CREDIT) totalCredit += t.amount else totalPayment += t.amount
        }

        document.add(table)
        document.add(Paragraph(" "))

        // সারসংক্ষেপ
        val closingBalance = openingBalance + totalCredit - totalPayment
        document.add(Paragraph("প্রারম্ভিক ব্যালেন্স: ${NumberFormatUtils.formatAmount(openingBalance)}").setFont(regularFont).setFontSize(12f))
        document.add(Paragraph("মোট ধার: ${NumberFormatUtils.formatAmount(totalCredit)}").setFont(semiBoldFont).setFontSize(12f))
        document.add(Paragraph("মোট পরিশোধ: ${NumberFormatUtils.formatAmount(totalPayment)}").setFont(semiBoldFont).setFontSize(12f))
        document.add(Paragraph("সমাপনী বাকি: ${NumberFormatUtils.formatAmount(closingBalance)}").setFont(boldFont).setFontSize(14f))

        document.close()
        file
    }
}
