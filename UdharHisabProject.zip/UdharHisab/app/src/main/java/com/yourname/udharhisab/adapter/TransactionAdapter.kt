package com.yourname.udharhisab.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.yourname.udharhisab.R
import com.yourname.udharhisab.data.model.Transaction
import com.yourname.udharhisab.databinding.ItemTransactionBinding
import com.yourname.udharhisab.utils.Constants
import com.yourname.udharhisab.utils.DateUtils
import com.yourname.udharhisab.utils.NumberFormatUtils
import com.yourname.udharhisab.utils.ProductIconMapper

class TransactionAdapter(
    private val onTransactionClick: (Transaction) -> Unit
) : ListAdapter<Transaction, TransactionAdapter.TransactionViewHolder>(TransactionDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TransactionViewHolder {
        val binding = ItemTransactionBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return TransactionViewHolder(binding)
    }

    override fun onBindViewHolder(holder: TransactionViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class TransactionViewHolder(
        private val binding: ItemTransactionBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(transaction: Transaction) {
            binding.tvProductName.text = transaction.productName.ifEmpty {
                binding.root.context.getString(R.string.transaction_fallback)
            }
            binding.tvAmount.text = NumberFormatUtils.formatAmount(transaction.amount)
            binding.tvDate.text = DateUtils.formatDate(transaction.date)
            binding.tvNote.text = transaction.note

            // Credit = Green, Payment = Red
            val isCredit = transaction.type == Constants.TYPE_CREDIT
            val colorRes = if (isCredit) R.color.green else R.color.red
            val bgColorRes = if (isCredit) R.color.green_light else R.color.red_light

            binding.tvAmount.setTextColor(ContextCompat.getColor(binding.root.context, colorRes))
            binding.cardContainer.setCardBackgroundColor(
                ContextCompat.getColor(binding.root.context, bgColorRes)
            )

            // Product icon
            val iconDrawable = ProductIconMapper.getDrawable(binding.root.context, transaction.productName)
            binding.imgProduct.setImageDrawable(iconDrawable)

            binding.root.setOnClickListener { onTransactionClick(transaction) }
        }
    }
}

class TransactionDiffCallback : DiffUtil.ItemCallback<Transaction>() {
    override fun areItemsTheSame(oldItem: Transaction, newItem: Transaction): Boolean {
        return oldItem.id == newItem.id
    }

    override fun areContentsTheSame(oldItem: Transaction, newItem: Transaction): Boolean {
        return oldItem == newItem
    }
}
