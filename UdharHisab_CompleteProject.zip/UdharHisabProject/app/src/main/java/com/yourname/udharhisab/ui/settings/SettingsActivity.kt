package com.yourname.udharhisab.ui.settings

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.gms.ads.MobileAds
import com.yourname.udharhisab.R
import com.yourname.udharhisab.databinding.ActivitySettingsBinding
import com.yourname.udharhisab.utils.JsonBackupManager
import kotlinx.coroutines.launch

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        setupLanguageSelector()
        setupBackupRestore()
        setupAbout()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = getString(R.string.nav_settings)
        binding.toolbar.setNavigationOnClickListener { finish() }
    }

    private fun setupLanguageSelector() {
        val languages = arrayOf("English", "Bengali", "Hindi", "Tamil", "Telugu", "Marathi",
            "Gujarati", "Punjabi", "Malayalam", "Kannada", "Odia", "Assamese")
        val adapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, languages)
        binding.dropdownLanguage.setAdapter(adapter)
    }

    private fun setupBackupRestore() {
        binding.btnBackup.setOnClickListener {
            lifecycleScope.launch {
                try {
                    val file = JsonBackupManager.exportToJson(this@SettingsActivity)
                    Toast.makeText(this@SettingsActivity, "Backup saved: ${file.name}", Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    Toast.makeText(this@SettingsActivity, "Backup failed: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }

        binding.btnRestore.setOnClickListener {
            // Show file picker dialog
            Toast.makeText(this, "Restore feature coming soon", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setupAbout() {
        binding.btnPrivacyPolicy.setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://your-website.com/privacy"))
            startActivity(intent)
        }

        binding.btnRateApp.setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW,
                Uri.parse("https://play.google.com/store/apps/details?id=${packageName}"))
            startActivity(intent)
        }

        binding.btnShareApp.setOnClickListener {
            val shareText = "Check out Udhar Hisab - the best app for tracking credit and payments!

" +
                    "https://play.google.com/store/apps/details?id=${packageName}"
            val intent = Intent(Intent.ACTION_SEND)
            intent.type = "text/plain"
            intent.putExtra(Intent.EXTRA_TEXT, shareText)
            startActivity(Intent.createChooser(intent, "Share via"))
        }
    }
}
