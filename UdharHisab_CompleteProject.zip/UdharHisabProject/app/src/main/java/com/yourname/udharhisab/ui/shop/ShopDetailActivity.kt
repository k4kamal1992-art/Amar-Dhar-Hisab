package com.yourname.udharhisab.ui.shop

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.gms.ads.AdRequest
import com.yourname.udharhisab.R
import com.yourname.udharhisab.UdharHisabApp
import com.yourname.udharhisab.adapter.TransactionAdapter
import com.yourname.udharhisab.databinding.ActivityShopDetailBinding
import com.yourname.udharhisab.ui.entry.NewEntryActivity
import com.yourname.udharhisab.utils.Constants
import com.yourname.udharhisab.utils.NumberFormatUtils
import kotlinx.coroutines.launch

class ShopDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityShopDetailBinding
    private lateinit var viewModel: ShopDetailViewModel
    private lateinit var transactionAdapter: TransactionAdapter
    private var shopId: Long = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityShopDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        shopId = intent.getLongExtra("shop_id", -1)
        if (shopId == -1L) {
            finish()
            return
        }

        val factory = ShopDetailViewModelFactory(application, shopId)
        viewModel = ViewModelProvider(this, factory)[ShopDetailViewModel::class.java]

        setupToolbar()
        setupRecyclerView()
        setupAds()
        setupButtons()
        observeData()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }
    }

    private fun setupRecyclerView() {
        transactionAdapter = TransactionAdapter { transaction ->
            // Show options: Edit or Delete
            AlertDialog.Builder(this)
                .setTitle(transaction.productName)
                .setItems(arrayOf("Edit", "Delete")) { _, which ->
                    when (which) {
                        0 -> { /* Edit */ }
                        1 -> deleteTransaction(transaction)
                    }
                }
                .show()
        }
        binding.recyclerTransactions.layoutManager = LinearLayoutManager(this)
        binding.recyclerTransactions.adapter = transactionAdapter
    }

    private fun setupAds() {
        val adRequest = AdRequest.Builder().build()
        binding.adView.loadAd(adRequest)
    }

    private fun setupButtons() {
        binding.fabAddEntry.setOnClickListener {
            val intent = Intent(this, NewEntryActivity::class.java)
            intent.putExtra("shop_id", shopId)
            startActivity(intent)
        }

        binding.btnShare.setOnClickListener {
            shareShopDetails()
        }
    }

    private fun observeData() {
        viewModel.shop.observe(this) { shop ->
            supportActionBar?.title = shop.name
            binding.tvOwnerName.text = shop.ownerName
            binding.tvPhone.text = shop.phone
            binding.tvAddress.text = shop.address
        }

        viewModel.transactions.observe(this) { transactions ->
            transactionAdapter.submitList(transactions)
        }

        viewModel.balance.observe(this) { balance ->
            binding.tvBalance.text = NumberFormatUtils.formatAmount(balance)
            val color = if (balance >= 0) R.color.green else R.color.red
            binding.tvBalance.setTextColor(getColor(color))
        }

        viewModel.totals.observe(this) { totals ->
            binding.tvTotalCredit.text = NumberFormatUtils.formatAmount(totals.totalCredit)
            binding.tvTotalPayment.text = NumberFormatUtils.formatAmount(totals.totalPayment)
        }
    }

    private fun deleteTransaction(transaction: com.yourname.udharhisab.data.model.Transaction) {
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.delete))
            .setMessage(getString(R.string.confirm_delete))
            .setPositiveButton(getString(R.string.delete)) { _, _ ->
                lifecycleScope.launch {
                    viewModel.deleteTransaction(transaction)
                    Toast.makeText(this@ShopDetailActivity, getString(R.string.transaction_deleted), Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun shareShopDetails() {
        val shareText = buildString {
            appendLine("Udhar Hisab Report")
            appendLine("Shop: ${viewModel.shop.value?.name}")
            appendLine("Balance: ${binding.tvBalance.text}")
        }
        val intent = Intent(Intent.ACTION_SEND)
        intent.type = "text/plain"
        intent.putExtra(Intent.EXTRA_TEXT, shareText)
        startActivity(Intent.createChooser(intent, "Share via"))
    }
}
