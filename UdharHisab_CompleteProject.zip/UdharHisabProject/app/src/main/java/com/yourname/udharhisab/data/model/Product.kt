package com.yourname.udharhisab.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Product entity - pre-populated product data for icon mapping
 */
@Entity(tableName = "products")
data class Product(
    @PrimaryKey
    val id: String,
    val nameBn: String,
    val nameHi: String,
    val nameEn: String,
    val iconName: String,
    val category: String
)
