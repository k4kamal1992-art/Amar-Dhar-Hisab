package com.yourname.udharhisab.ui.home

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.yourname.udharhisab.UdharHisabApp
import com.yourname.udharhisab.data.model.Shop
import com.yourname.udharhisab.data.model.Transaction
import com.yourname.udharhisab.data.repository.ShopRepository
import com.yourname.udharhisab.data.repository.TransactionRepository
import kotlinx.coroutines.launch

class HomeViewModel(application: Application) : AndroidViewModel(application) {

    private val shopRepository: ShopRepository = (application as UdharHisabApp).shopRepository
    private val transactionRepository: TransactionRepository = application.transactionRepository

    val allShops: LiveData<List<Shop>> = shopRepository.allShops
    val recentTransactions: LiveData<List<Transaction>> = transactionRepository.getRecentTransactions()

    private val _totalBalance = MutableLiveData<Double>()
    val totalBalance: LiveData<Double> = _totalBalance

    private val _totalShops = MutableLiveData<Int>()
    val totalShops: LiveData<Int> = _totalShops

    fun refreshStats() {
        viewModelScope.launch {
            val shops = allShops.value ?: emptyList()
            _totalShops.postValue(shops.size)
            // Calculate total balance across all shops
            var balance = 0.0
            shops.forEach { shop ->
                // This would need a more efficient query in production
            }
            _totalBalance.postValue(balance)
        }
    }
}
