package com.yourname.udharhisab.utils

import android.content.Context
import android.os.Environment
import com.itextpdf.kernel.pdf.PdfDocument
import com.itextpdf.kernel.pdf.PdfWriter
import com.itextpdf.layout.Document
import com.itextpdf.layout.element.Paragraph
import com.itextpdf.layout.element.Table
import com.yourname.udharhisab.data.model.Shop
import com.yourname.udharhisab.data.model.Transaction
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Generates PDF reports for shop transactions
 */
object PdfGenerator {

    suspend fun generateShopReport(
        context: Context,
        shop: Shop,
        transactions: List<Transaction>
    ): File = withContext(Dispatchers.IO) {
        val downloadsDir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
            ?: context.filesDir
        val file = File(downloadsDir, "udhar_hisab_${shop.name.replace(" ", "_")}.pdf")

        val writer = PdfWriter(file)
        val pdf = PdfDocument(writer)
        val document = Document(pdf)

        // Title
        document.add(Paragraph("Udhar Hisab - Transaction Report").setFontSize(20f))
        document.add(Paragraph("Shop: ${shop.name}").setFontSize(14f))
        document.add(Paragraph("Owner: ${shop.ownerName}").setFontSize(12f))
        document.add(Paragraph("Date: ${DateUtils.formatFull(System.currentTimeMillis())}").setFontSize(12f))
        document.add(Paragraph(" "))

        // Transactions table
        val table = Table(floatArrayOf(3f, 2f, 2f, 3f))
        table.addCell("Date")
        table.addCell("Type")
        table.addCell("Amount")
        table.addCell("Note")

        var totalCredit = 0.0
        var totalPayment = 0.0

        transactions.forEach { t ->
            table.addCell(DateUtils.formatDate(t.date))
            table.addCell(t.type)
            table.addCell(NumberFormatUtils.formatAmount(t.amount))
            table.addCell(t.note)

            if (t.type == Constants.TYPE_CREDIT) totalCredit += t.amount
            else totalPayment += t.amount
        }

        document.add(table)
        document.add(Paragraph(" "))

        // Summary
        document.add(Paragraph("Total Credit: ${NumberFormatUtils.formatAmount(totalCredit)}"))
        document.add(Paragraph("Total Payment: ${NumberFormatUtils.formatAmount(totalPayment)}"))
        document.add(Paragraph("Balance: ${NumberFormatUtils.formatAmount(totalCredit - totalPayment)}"))

        document.close()
        file
    }
}
