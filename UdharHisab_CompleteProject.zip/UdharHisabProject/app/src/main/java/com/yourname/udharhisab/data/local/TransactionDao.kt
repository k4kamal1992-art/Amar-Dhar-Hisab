package com.yourname.udharhisab.data.local

import androidx.lifecycle.LiveData
import androidx.room.*
import com.yourname.udharhisab.data.model.Transaction

@Dao
interface TransactionDao {

    @Query("SELECT * FROM transactions WHERE shopId = :shopId ORDER BY date DESC")
    fun getTransactionsByShop(shopId: Long): LiveData<List<Transaction>>

    @Query("SELECT * FROM transactions WHERE shopId = :shopId AND type = :type ORDER BY date DESC")
    fun getTransactionsByType(shopId: Long, type: String): LiveData<List<Transaction>>

    @Query("""
        SELECT 
            COALESCE(SUM(CASE WHEN type = 'CREDIT' THEN amount ELSE 0 END), 0) as totalCredit,
            COALESCE(SUM(CASE WHEN type = 'PAYMENT' THEN amount ELSE 0 END), 0) as totalPayment
        FROM transactions 
        WHERE shopId = :shopId
    """)
    fun getShopTotals(shopId: Long): LiveData<ShopTotals>

    @Query("""
        SELECT 
            COALESCE(SUM(CASE WHEN type = 'CREDIT' THEN amount ELSE 0 END), 0) -
            COALESCE(SUM(CASE WHEN type = 'PAYMENT' THEN amount ELSE 0 END), 0)
        FROM transactions 
        WHERE shopId = :shopId
    """)
    fun getShopBalance(shopId: Long): LiveData<Double>

    @Insert
    suspend fun insertTransaction(transaction: Transaction): Long

    @Update
    suspend fun updateTransaction(transaction: Transaction)

    @Delete
    suspend fun deleteTransaction(transaction: Transaction)

    @Query("SELECT * FROM transactions ORDER BY date DESC LIMIT 50")
    fun getRecentTransactions(): LiveData<List<Transaction>>

    @Query("SELECT * FROM transactions ORDER BY date DESC")
    fun getAllTransactions(): LiveData<List<Transaction>>

    @Query("SELECT * FROM transactions WHERE date BETWEEN :startDate AND :endDate ORDER BY date DESC")
    fun getTransactionsByDateRange(startDate: Long, endDate: Long): LiveData<List<Transaction>>
}

data class ShopTotals(
    val totalCredit: Double,
    val totalPayment: Double
)
