package com.yourname.udharhisab.utils

import java.text.NumberFormat
import java.util.*

/**
 * Number and currency formatting utilities
 */
object NumberFormatUtils {

    private val currencyFormat = NumberFormat.getCurrencyInstance(Locale("en", "IN"))
    private val numberFormat = NumberFormat.getNumberInstance(Locale("en", "IN"))

    init {
        currencyFormat.maximumFractionDigits = 0
    }

    fun formatCurrency(amount: Double): String {
        return currencyFormat.format(amount)
    }

    fun formatNumber(amount: Double): String {
        return numberFormat.format(amount)
    }

    fun formatAmount(amount: Double): String {
        return "₹ ${formatNumber(amount)}"
    }
}
