package com.yourname.udharhisab.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.yourname.udharhisab.data.model.Shop
import com.yourname.udharhisab.databinding.ItemShopBinding
import com.yourname.udharhisab.utils.NumberFormatUtils

class ShopAdapter(
    private val onShopClick: (Shop) -> Unit
) : ListAdapter<Shop, ShopAdapter.ShopViewHolder>(ShopDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ShopViewHolder {
        val binding = ItemShopBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ShopViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ShopViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class ShopViewHolder(
        private val binding: ItemShopBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(shop: Shop) {
            binding.tvShopName.text = shop.name
            binding.tvOwnerName.text = shop.ownerName
            binding.tvPhone.text = shop.phone

            // Show first letter as avatar
            val firstLetter = shop.name.firstOrNull()?.uppercase() ?: "?"
            binding.tvAvatar.text = firstLetter

            binding.root.setOnClickListener { onShopClick(shop) }
        }
    }
}

class ShopDiffCallback : DiffUtil.ItemCallback<Shop>() {
    override fun areItemsTheSame(oldItem: Shop, newItem: Shop): Boolean {
        return oldItem.id == newItem.id
    }

    override fun areContentsTheSame(oldItem: Shop, newItem: Shop): Boolean {
        return oldItem == newItem
    }
}
