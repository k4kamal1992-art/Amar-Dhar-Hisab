package com.yourname.udharhisab.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.yourname.udharhisab.data.model.Product
import com.yourname.udharhisab.data.model.Shop
import com.yourname.udharhisab.data.model.Transaction
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [Shop::class, Transaction::class, Product::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun shopDao(): ShopDao
    abstract fun transactionDao(): TransactionDao
    abstract fun productDao(): ProductDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "udhar_hisab_database"
                )
                .addCallback(DatabaseCallback())
                .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class DatabaseCallback : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                CoroutineScope(Dispatchers.IO).launch {
                    populateProducts(database.productDao())
                }
            }
        }

        private suspend fun populateProducts(productDao: ProductDao) {
            val products = listOf(
                Product("product_tea", "চা", "चाय", "Tea", "icon_tea", "tea_snacks"),
                Product("product_rice", "চাল", "चावल", "Rice", "icon_rice", "grocery"),
                Product("product_potato", "আলু", "आलू", "Potato", "icon_potato", "vegetables"),
                Product("product_onion", "পেঁয়াজ", "प्याज", "Onion", "icon_onion", "vegetables"),
                Product("product_dal", "ডাল", "दाल", "Dal", "icon_dal", "grocery"),
                Product("product_oil", "তেল", "तेल", "Oil", "icon_oil", "grocery"),
                Product("product_biscuit", "বিস্কুট", "बिस्कुट", "Biscuit", "icon_biscuit", "tea_snacks"),
                Product("product_egg", "ডিম", "अंडा", "Egg", "icon_egg", "grocery"),
                Product("product_milk", "দুধ", "दूध", "Milk", "icon_milk", "grocery"),
                Product("product_sugar", "চিনি", "चीनी", "Sugar", "icon_sugar", "grocery"),
                Product("product_salt", "লবণ", "नमक", "Salt", "icon_salt", "grocery"),
                Product("product_soap", "সাবান", "साबुन", "Soap", "icon_soap", "grocery"),
                Product("product_bread", "রুটি", "रोटी", "Bread", "icon_bread", "grocery"),
                Product("product_cigarette", "সিগারেট", "सिगरेट", "Cigarette", "icon_cigarette", "tea_snacks"),
                Product("product_paan", "পান", "पान", "Paan", "icon_paan", "tea_snacks"),
                Product("product_wheat", "গম", "गेहूं", "Wheat", "icon_wheat", "grocery"),
                Product("product_flour", "ময়দা", "मैदा", "Flour", "icon_flour", "grocery"),
                Product("product_tomato", "টমেটো", "टमाटर", "Tomato", "icon_tomato", "vegetables"),
                Product("product_ginger", "আদা", "अदरक", "Ginger", "icon_ginger", "vegetables"),
                Product("product_garlic", "রসুন", "लहसुन", "Garlic", "icon_garlic", "vegetables"),
                Product("product_chili", "মরিচ", "मिर्च", "Chili", "icon_chili", "vegetables"),
                Product("product_turmeric", "হলুদ", "हल्दी", "Turmeric", "icon_turmeric", "spices"),
                Product("product_cumin", "জিরা", "जीरा", "Cumin", "icon_cumin", "spices"),
                Product("product_corinader", "ধনে", "धनिया", "Coriander", "icon_coriander", "spices"),
                Product("product_ghee", "ঘি", "घी", "Ghee", "icon_ghee", "grocery"),
                Product("product_butter", "মাখন", "मक्खन", "Butter", "icon_butter", "grocery"),
                Product("product_cheese", "পনির", "पनीर", "Cheese", "icon_cheese", "grocery"),
                Product("product_yogurt", "দই", "दही", "Yogurt", "icon_yogurt", "grocery"),
                Product("product_coffee", "কফি", "कॉफ़ी", "Coffee", "icon_coffee", "tea_snacks"),
                Product("product_cake", "কেক", "केक", "Cake", "icon_cake", "tea_snacks"),
                Product("product_namkeen", "নমকीन", "नमकीन", "Namkeen", "icon_namkeen", "tea_snacks"),
                Product("product_cold_drink", "ঠান্ডা পানীয়", "थंडा पेय", "Cold Drink", "icon_cold_drink", "beverages"),
                Product("product_water", "জল", "पानी", "Water", "icon_water", "beverages"),
                Product("product_juice", "জুস", "जूस", "Juice", "icon_juice", "beverages"),
                Product("product_noodles", "চাউমিন", "चाउमीन", "Noodles", "icon_noodles", "instant_food"),
                Product("product_pasta", "পাস্তা", "पास्ता", "Pasta", "icon_pasta", "instant_food"),
                Product("product_sauce", "সস", "सॉस", "Sauce", "icon_sauce", "instant_food"),
                Product("product_ketchup", "টমেটো সস", "टमाटर सॉस", "Ketchup", "icon_ketchup", "instant_food"),
                Product("product_shampoo", "শ্যাম্পু", "शैम्पू", "Shampoo", "icon_shampoo", "personal_care"),
                Product("product_toothpaste", "টুথপেস্ট", "टूथपेस्ट", "Toothpaste", "icon_toothpaste", "personal_care")
            )
            products.forEach { productDao.insertProduct(it) }
        }
    }
}
