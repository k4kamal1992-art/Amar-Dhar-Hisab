package com.yourname.udharhisab.ui.entry

import android.app.DatePickerDialog
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.yourname.udharhisab.R
import com.yourname.udharhisab.UdharHisabApp
import com.yourname.udharhisab.data.model.Transaction
import com.yourname.udharhisab.databinding.ActivityNewEntryBinding
import com.yourname.udharhisab.utils.Constants
import com.yourname.udharhisab.utils.DateUtils
import kotlinx.coroutines.launch
import java.util.*

class NewEntryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityNewEntryBinding
    private var selectedDate: Long = System.currentTimeMillis()
    private var selectedShopId: Long = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNewEntryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        selectedShopId = intent.getLongExtra("shop_id", -1)

        setupToolbar()
        setupTransactionType()
        setupDatePicker()
        setupSaveButton()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = getString(R.string.new_entry)
        binding.toolbar.setNavigationOnClickListener { finish() }
    }

    private fun setupTransactionType() {
        val types = arrayOf(Constants.TYPE_CREDIT, Constants.TYPE_PAYMENT)
        val adapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, types)
        binding.dropdownType.setAdapter(adapter)
        binding.dropdownType.setText(Constants.TYPE_CREDIT, false)
    }

    private fun setupDatePicker() {
        binding.etDate.setText(DateUtils.formatDate(selectedDate))
        binding.etDate.setOnClickListener {
            val cal = Calendar.getInstance()
            cal.timeInMillis = selectedDate
            DatePickerDialog(
                this,
                { _, year, month, day ->
                    cal.set(year, month, day)
                    selectedDate = cal.timeInMillis
                    binding.etDate.setText(DateUtils.formatDate(selectedDate))
                },
                cal.get(Calendar.YEAR),
                cal.get(Calendar.MONTH),
                cal.get(Calendar.DAY_OF_MONTH)
            ).show()
        }
    }

    private fun setupSaveButton() {
        binding.btnSave.setOnClickListener {
            val amountStr = binding.etAmount.text.toString().trim()
            val productName = binding.etProductName.text.toString().trim()
            val quantityStr = binding.etQuantity.text.toString().trim()
            val note = binding.etNote.text.toString().trim()
            val type = binding.dropdownType.text.toString()

            if (amountStr.isEmpty()) {
                binding.etAmount.error = getString(R.string.error_amount)
                return@setOnClickListener
            }

            val amount = amountStr.toDoubleOrNull() ?: 0.0
            val quantity = quantityStr.toIntOrNull() ?: 1

            val transaction = Transaction(
                shopId = selectedShopId,
                type = type,
                amount = amount,
                productName = productName,
                quantity = quantity,
                note = note,
                date = selectedDate
            )

            lifecycleScope.launch {
                (application as UdharHisabApp).transactionRepository.insert(transaction)
                Toast.makeText(this@NewEntryActivity, getString(R.string.transaction_saved), Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }
}
