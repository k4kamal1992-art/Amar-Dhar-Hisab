package com.yourname.udharhisab.utils

import android.content.Context
import android.graphics.drawable.Drawable
import androidx.core.content.ContextCompat
import com.yourname.udharhisab.R

/**
 * Maps product names to icon resources
 * Supports 12 languages via keyword matching
 */
object ProductIconMapper {

    private val iconMap = mapOf(
        // Tea & Snacks
        "tea" to R.drawable.ic_product_tea,
        "চা" to R.drawable.ic_product_tea,
        "चाय" to R.drawable.ic_product_tea,
        "coffee" to R.drawable.ic_product_coffee,
        "কফি" to R.drawable.ic_product_coffee,
        "biscuit" to R.drawable.ic_product_biscuit,
        "বিস্কুট" to R.drawable.ic_product_biscuit,
        "cigarette" to R.drawable.ic_product_cigarette,
        "সিগারেট" to R.drawable.ic_product_cigarette,
        "paan" to R.drawable.ic_product_paan,
        "পান" to R.drawable.ic_product_paan,
        "namkeen" to R.drawable.ic_product_namkeen,
        "নমকीन" to R.drawable.ic_product_namkeen,
        "cake" to R.drawable.ic_product_cake,
        "কেক" to R.drawable.ic_product_cake,

        // Grocery
        "rice" to R.drawable.ic_product_rice,
        "চাল" to R.drawable.ic_product_rice,
        "dal" to R.drawable.ic_product_dal,
        "ডাল" to R.drawable.ic_product_dal,
        "oil" to R.drawable.ic_product_oil,
        "তেল" to R.drawable.ic_product_oil,
        "egg" to R.drawable.ic_product_egg,
        "ডিম" to R.drawable.ic_product_egg,
        "milk" to R.drawable.ic_product_milk,
        "দুধ" to R.drawable.ic_product_milk,
        "sugar" to R.drawable.ic_product_sugar,
        "চিনি" to R.drawable.ic_product_sugar,
        "salt" to R.drawable.ic_product_salt,
        "লবণ" to R.drawable.ic_product_salt,
        "soap" to R.drawable.ic_product_soap,
        "সাবান" to R.drawable.ic_product_soap,
        "bread" to R.drawable.ic_product_bread,
        "রুটি" to R.drawable.ic_product_bread,
        "wheat" to R.drawable.ic_product_wheat,
        "গম" to R.drawable.ic_product_wheat,
        "flour" to R.drawable.ic_product_flour,
        "ময়দা" to R.drawable.ic_product_flour,
        "ghee" to R.drawable.ic_product_ghee,
        "ঘি" to R.drawable.ic_product_ghee,
        "butter" to R.drawable.ic_product_butter,
        "মাখন" to R.drawable.ic_product_butter,
        "cheese" to R.drawable.ic_product_cheese,
        "পনির" to R.drawable.ic_product_cheese,
        "yogurt" to R.drawable.ic_product_yogurt,
        "দই" to R.drawable.ic_product_yogurt,

        // Vegetables
        "potato" to R.drawable.ic_product_potato,
        "আলু" to R.drawable.ic_product_potato,
        "onion" to R.drawable.ic_product_onion,
        "পেঁয়াজ" to R.drawable.ic_product_onion,
        "tomato" to R.drawable.ic_product_tomato,
        "টমেটো" to R.drawable.ic_product_tomato,
        "ginger" to R.drawable.ic_product_ginger,
        "আদা" to R.drawable.ic_product_ginger,
        "garlic" to R.drawable.ic_product_garlic,
        "রসুন" to R.drawable.ic_product_garlic,
        "chili" to R.drawable.ic_product_chili,
        "মরিচ" to R.drawable.ic_product_chili,

        // Spices
        "turmeric" to R.drawable.ic_product_turmeric,
        "হলুদ" to R.drawable.ic_product_turmeric,
        "cumin" to R.drawable.ic_product_cumin,
        "জিরা" to R.drawable.ic_product_cumin,
        "coriander" to R.drawable.ic_product_coriander,
        "ধনে" to R.drawable.ic_product_coriander,

        // Beverages
        "cold_drink" to R.drawable.ic_product_cold_drink,
        "water" to R.drawable.ic_product_water,
        "জল" to R.drawable.ic_product_water,
        "juice" to R.drawable.ic_product_juice,
        "জুস" to R.drawable.ic_product_juice,

        // Instant Food
        "noodles" to R.drawable.ic_product_noodles,
        "চাউমিন" to R.drawable.ic_product_noodles,
        "pasta" to R.drawable.ic_product_pasta,
        "সস" to R.drawable.ic_product_sauce,
        "ketchup" to R.drawable.ic_product_ketchup,

        // Personal Care
        "shampoo" to R.drawable.ic_product_shampoo,
        "শ্যাম্পু" to R.drawable.ic_product_shampoo,
        "toothpaste" to R.drawable.ic_product_toothpaste,
        "টুথপেস্ট" to R.drawable.ic_product_toothpaste
    )

    fun getIconForProduct(productName: String): Int {
        // Exact match
        iconMap[productName.lowercase()]?.let { return it }

        // Partial match
        iconMap.keys.forEach { key ->
            if (productName.lowercase().contains(key.lowercase())) {
                return iconMap[key]!!
            }
        }

        // Default icon
        return R.drawable.ic_product_default
    }

    fun getDrawable(context: Context, productName: String): Drawable? {
        val iconRes = getIconForProduct(productName)
        return ContextCompat.getDrawable(context, iconRes)
    }
}
