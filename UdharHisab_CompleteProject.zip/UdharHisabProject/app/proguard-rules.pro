# ProGuard rules for Udhar Hisab
-keep class com.yourname.udharhisab.data.model.** { *; }
