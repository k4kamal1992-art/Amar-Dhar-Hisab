package com.amardhar.hisab.utils

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import com.amardhar.hisab.data.Shop
import com.amardhar.hisab.data.TransactionWithShop
import java.io.OutputStream

/**
 * একটি দোকানের হিসাব PDF আকারে তৈরি করে।
 * নোট: বাংলা ফন্ট রেন্ডারিং ডিভাইসের সিস্টেম ফন্টের উপর নির্ভরশীল —
 * আধুনিক Android ভার্সনে (৭+) সাধারণত ঠিকভাবে দেখায়।
 */
object PdfReportGenerator {

    fun generate(shop: Shop, transactions: List<TransactionWithShop>, outputStream: OutputStream) {
        val document = PdfDocument()
        val pageWidth = 595 // A4 প্রায় ৭২dpi
        val pageHeight = 842
        var pageNumber = 1
        var y = 40

        val titlePaint = Paint().apply { textSize = 18f; isFakeBoldText = true }
        val headerPaint = Paint().apply { textSize = 12f; isFakeBoldText = true }
        val normalPaint = Paint().apply { textSize = 11f }
        val linePaint = Paint().apply { strokeWidth = 1f; color = 0xFFCCCCCC.toInt() }

        var pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
        var page = document.startPage(pageInfo)
        var canvas: Canvas = page.canvas

        canvas.drawText("আমার ধার হিসাব", 40f, y.toFloat(), titlePaint)
        y += 26
        canvas.drawText("দোকান: ${shop.name}", 40f, y.toFloat(), headerPaint)
        y += 18
        if (shop.ownerName.isNotBlank()) {
            canvas.drawText("মালিক: ${shop.ownerName}", 40f, y.toFloat(), normalPaint)
            y += 18
        }
        y += 8
        canvas.drawLine(40f, y.toFloat(), (pageWidth - 40).toFloat(), y.toFloat(), linePaint)
        y += 20

        // টেবিল হেডার
        canvas.drawText("তারিখ", 40f, y.toFloat(), headerPaint)
        canvas.drawText("ধরন", 160f, y.toFloat(), headerPaint)
        canvas.drawText("সময়", 260f, y.toFloat(), headerPaint)
        canvas.drawText("পরিমাণ (₹)", 420f, y.toFloat(), headerPaint)
        y += 10
        canvas.drawLine(40f, y.toFloat(), (pageWidth - 40).toFloat(), y.toFloat(), linePaint)
        y += 20

        var totalCredit = 0.0
        var totalPayment = 0.0

        for (entry in transactions) {
            if (y > pageHeight - 80) {
                document.finishPage(page)
                pageNumber++
                pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
                page = document.startPage(pageInfo)
                canvas = page.canvas
                y = 40
            }

            val tx = entry.transaction
            val typeLabel = if (tx.type == "CREDIT") "ধার" else "পরিশোধ"
            if (tx.type == "CREDIT") totalCredit += tx.totalAmount else totalPayment += tx.totalAmount

            canvas.drawText(tx.dateString, 40f, y.toFloat(), normalPaint)
            canvas.drawText(typeLabel, 160f, y.toFloat(), normalPaint)
            canvas.drawText(tx.timeString, 260f, y.toFloat(), normalPaint)
            canvas.drawText(tx.totalAmount.toString(), 420f, y.toFloat(), normalPaint)
            y += 20
        }

        y += 10
        canvas.drawLine(40f, y.toFloat(), (pageWidth - 40).toFloat(), y.toFloat(), linePaint)
        y += 22
        canvas.drawText("মোট ধার: ₹$totalCredit", 40f, y.toFloat(), headerPaint)
        y += 18
        canvas.drawText("মোট পরিশোধ: ₹$totalPayment", 40f, y.toFloat(), headerPaint)
        y += 18
        canvas.drawText("বর্তমান বাকি: ₹${totalCredit - totalPayment}", 40f, y.toFloat(), headerPaint)

        document.finishPage(page)
        document.writeTo(outputStream)
        document.close()
    }
}
