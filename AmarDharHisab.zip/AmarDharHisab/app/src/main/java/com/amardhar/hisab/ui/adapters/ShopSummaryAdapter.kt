package com.amardhar.hisab.ui.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.amardhar.hisab.R
import com.amardhar.hisab.data.ShopSummary
import com.amardhar.hisab.utils.IconMapper

class ShopSummaryAdapter(
    private var list: List<ShopSummary>,
    private val onClick: ((ShopSummary) -> Unit)? = null
) : RecyclerView.Adapter<ShopSummaryAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.iv_shop_icon)
        val name: TextView = view.findViewById(R.id.tv_shop_name)
        val owner: TextView = view.findViewById(R.id.tv_owner_name)
        val due: TextView = view.findViewById(R.id.tv_due)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_shop_summary, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = list[position]
        holder.icon.setImageResource(IconMapper.getShopIcon(item.shopName))
        holder.name.text = item.shopName
        holder.owner.text = if (item.ownerName.isNotBlank()) item.ownerName else "—"

        val context = holder.itemView.context
        holder.due.text = "₹ ${item.due}"
        val color = if (item.due > 0) R.color.warm_red else R.color.soft_green
        holder.due.setTextColor(ContextCompat.getColor(context, color))

        holder.itemView.setOnClickListener { onClick?.invoke(item) }
    }

    override fun getItemCount() = list.size

    fun updateList(newList: List<ShopSummary>) {
        list = newList
        notifyDataSetChanged()
    }
}
