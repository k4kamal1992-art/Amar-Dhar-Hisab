package com.amardhar.hisab.ui.fragments

import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.amardhar.hisab.AmarDharApp
import com.amardhar.hisab.R
import com.amardhar.hisab.ui.adapters.ShopSummaryAdapter
import kotlinx.coroutines.launch

class AnalyticsFragment : Fragment(R.layout.fragment_analytics) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val app = requireActivity().application as AmarDharApp
        val dao = app.database.appDao()

        val barCredit = view.findViewById<View>(R.id.bar_credit)
        val barPayment = view.findViewById<View>(R.id.bar_payment)
        val tvCreditLabel = view.findViewById<TextView>(R.id.tv_bar_credit_label)
        val tvPaymentLabel = view.findViewById<TextView>(R.id.tv_bar_payment_label)

        val rv = view.findViewById<RecyclerView>(R.id.rv_top_due_shops)
        rv.layoutManager = LinearLayoutManager(context)
        val adapter = ShopSummaryAdapter(emptyList())
        rv.adapter = adapter

        viewLifecycleOwner.lifecycleScope.launch {
            dao.getShopSummaries().collect { summaries ->
                val totalCredit = summaries.sumOf { it.totalCredit }
                val totalPayment = summaries.sumOf { it.totalPayment }
                val maxVal = maxOf(totalCredit, totalPayment, 1.0)

                tvCreditLabel.text = "ধার: ₹$totalCredit"
                tvPaymentLabel.text = "পরিশোধ: ₹$totalPayment"

                barCredit.layoutParams = (barCredit.layoutParams as LinearLayout.LayoutParams).apply {
                    weight = (totalCredit / maxVal).toFloat().coerceAtLeast(0.01f)
                }
                barCredit.requestLayout()

                barPayment.layoutParams = (barPayment.layoutParams as LinearLayout.LayoutParams).apply {
                    weight = (totalPayment / maxVal).toFloat().coerceAtLeast(0.01f)
                }
                barPayment.requestLayout()

                val topDue = summaries.filter { it.due > 0 }.sortedByDescending { it.due }.take(10)
                adapter.updateList(topDue)
            }
        }
    }
}
