package com.amardhar.hisab.data

/**
 * সম্পূর্ণ অ্যাপ ডেটার একটি স্ন্যাপশট — ব্যাকআপ/রিস্টোরের জন্য ব্যবহৃত হয়।
 */
data class BackupPayload(
    val exportedAt: Long = System.currentTimeMillis(),
    val appVersion: String = "1.0",
    val shops: List<Shop>,
    val products: List<Product>,
    val transactions: List<Transaction>,
    val transactionItems: List<TransactionItem>,
    val priceHistory: List<ProductPriceHistory>
)
