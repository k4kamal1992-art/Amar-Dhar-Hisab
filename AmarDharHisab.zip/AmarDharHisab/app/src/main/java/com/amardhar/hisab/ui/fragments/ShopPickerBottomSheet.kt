package com.amardhar.hisab.ui.fragments

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.amardhar.hisab.AmarDharApp
import com.amardhar.hisab.R
import com.amardhar.hisab.data.Shop
import com.amardhar.hisab.ui.adapters.ShopPickerAdapter
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import kotlinx.coroutines.launch

/**
 * দোকান নির্বাচনের জন্য আধুনিক bottom sheet — সার্চসহ, নতুন দোকান যোগ করার অপশনসহ।
 */
class ShopPickerBottomSheet(
    private val onShopSelected: (Shop) -> Unit
) : BottomSheetDialogFragment() {

    private var allShops: List<Shop> = emptyList()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.bottom_sheet_shop_picker, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val app = requireActivity().application as AmarDharApp
        val dao = app.database.appDao()

        val rv = view.findViewById<RecyclerView>(R.id.rv_picker_shops)
        rv.layoutManager = LinearLayoutManager(context)
        val adapter = ShopPickerAdapter(emptyList()) { shop ->
            onShopSelected(shop)
            dismiss()
        }
        rv.adapter = adapter

        val etSearch = view.findViewById<EditText>(R.id.et_picker_search)
        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val q = s.toString()
                adapter.updateList(
                    if (q.isBlank()) allShops else allShops.filter { it.name.contains(q, ignoreCase = true) }
                )
            }
        })

        viewLifecycleOwner.lifecycleScope.launch {
            dao.getAllShops().collect { shops ->
                allShops = shops
                adapter.updateList(shops)
            }
        }

        view.findViewById<TextView>(R.id.tv_picker_add_shop).setOnClickListener {
            showAddShopDialog(dao)
        }
    }

    private fun showAddShopDialog(dao: com.amardhar.hisab.data.AppDao) {
        val dialogView = LayoutInflater.from(context).inflate(R.layout.dialog_add_shop, null)
        val etName = dialogView.findViewById<EditText>(R.id.et_dialog_shop_name)
        val etOwner = dialogView.findViewById<EditText>(R.id.et_dialog_owner_name)

        AlertDialog.Builder(requireContext())
            .setTitle("নতুন দোকান যোগ করুন")
            .setView(dialogView)
            .setPositiveButton("সেভ করুন") { _, _ ->
                val name = etName.text.toString().trim()
                if (name.isEmpty()) {
                    Toast.makeText(context, "দোকানের নাম দিন", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                viewLifecycleOwner.lifecycleScope.launch {
                    val ownerName = etOwner.text.toString().trim()
                    val newId = dao.insertShop(Shop(name = name, ownerName = ownerName))
                    onShopSelected(Shop(id = newId, name = name, ownerName = ownerName))
                    dismiss()
                }
            }
            .setNegativeButton("বাতিল", null)
            .show()
    }
}
