package com.amardhar.hisab.ui.fragments

import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.fragment.app.Fragment
import com.amardhar.hisab.AmarDharApp
import com.amardhar.hisab.R
import com.amardhar.hisab.data.Transaction
import com.amardhar.hisab.data.TransactionItem
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class QuickEntryFragment : Fragment(R.layout.fragment_quick_entry) {
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val spinner = view.findViewById<Spinner>(R.id.spinner_shops)
        val etProd = view.findViewById<EditText>(R.id.et_product_name)
        val etAmt = view.findViewById<EditText>(R.id.et_amount)
        val btnSave = view.findViewById<Button>(R.id.btn_save_credit)
        val app = requireActivity().application as AmarDharApp
        
        var shopId: Long = 0

        // দোকান লিস্ট লোড করা
        MainScope().launch {
            app.database.appDao().getAllShops().collect { shops ->
                val names = shops.map { it.name }
                val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, names)
                spinner.adapter = adapter
                spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(p0: AdapterView<*>?, p1: View?, position: Int, id: Long) {
                        shopId = shops[position].id
                    }
                    override fun onNothingSelected(p0: AdapterView<*>?) {}
                }
            }
        }

        btnSave.setOnClickListener {
            val amount = etAmt.text.toString().toDoubleOrNull() ?: 0.0
            if (shopId != 0L && amount > 0) {
                MainScope().launch {
                    val date = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(Date())
                    val time = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
                    
                    val tx = Transaction(shopId = shopId, totalAmount = amount, type = "CREDIT", dateString = date, timeString = time)
                    val item = TransactionItem(transactionId = 0, productId = 0, productNameSnapshot = etProd.text.toString(), unitPriceSnapshot = amount, quantity = 1.0, subtotal = amount)
                    
                    app.database.appDao().saveCreditEntry(tx, listOf(item))
                    Toast.makeText(context, "হিসাব সেভ হয়েছে!", Toast.LENGTH_SHORT).show()
                    etProd.text.clear()
                    etAmt.text.clear()
                }
            } else {
                Toast.makeText(context, "সঠিক তথ্য দিন", Toast.LENGTH_SHORT).show()
            }
        }
    }
}