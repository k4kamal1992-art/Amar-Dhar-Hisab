package com.amardhar.hisab.ui.fragments

import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.amardhar.hisab.AmarDharApp
import com.amardhar.hisab.R
import com.amardhar.hisab.data.Product
import com.amardhar.hisab.data.Shop
import com.amardhar.hisab.data.Transaction
import com.amardhar.hisab.data.TransactionItem
import com.amardhar.hisab.ui.adapters.QuickEntryProductAdapter
import com.amardhar.hisab.utils.IconMapper
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class QuickEntryFragment : Fragment(R.layout.fragment_quick_entry) {

    private var isPaymentMode = false
    private var currentShopId: Long = 0
    private var currentProducts: List<Product> = emptyList()
    private var currentProductsTotal: Double = 0.0

    private var productsJob: Job? = null
    private var dueJob: Job? = null

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val app = requireActivity().application as AmarDharApp
        val dao = app.database.appDao()

        val rowSelectShop = view.findViewById<View>(R.id.row_select_shop)
        val ivSelectedShopIcon = view.findViewById<ImageView>(R.id.iv_selected_shop_icon)
        val tvSelectedShopName = view.findViewById<TextView>(R.id.tv_selected_shop_name)
        val btnModeCredit = view.findViewById<Button>(R.id.btn_mode_credit)
        val btnModePayment = view.findViewById<Button>(R.id.btn_mode_payment)
        val layoutCredit = view.findViewById<View>(R.id.layout_credit_mode)
        val layoutPayment = view.findViewById<View>(R.id.layout_payment_mode)
        val rvProducts = view.findViewById<RecyclerView>(R.id.rv_qe_products)
        val tvNoProducts = view.findViewById<TextView>(R.id.tv_no_products)
        val etManualName = view.findViewById<EditText>(R.id.et_manual_product_name)
        val etManualAmount = view.findViewById<EditText>(R.id.et_manual_amount)
        val tvTotal = view.findViewById<TextView>(R.id.tv_qe_total)
        val tvCurrentDue = view.findViewById<TextView>(R.id.tv_current_due)
        val etPaymentAmount = view.findViewById<EditText>(R.id.et_payment_amount)
        val btnSave = view.findViewById<Button>(R.id.btn_save_entry)

        rvProducts.layoutManager = LinearLayoutManager(context)

        fun updateGrandTotal() {
            val manualAmt = etManualAmount.text.toString().toDoubleOrNull() ?: 0.0
            tvTotal.text = "মোট: ₹${currentProductsTotal + manualAmt}"
        }

        fun refreshProductAdapter() {
            val adapter = QuickEntryProductAdapter(currentProducts) { total ->
                currentProductsTotal = total
                updateGrandTotal()
            }
            rvProducts.adapter = adapter
            tvNoProducts.visibility = if (currentProducts.isEmpty()) View.VISIBLE else View.GONE
            currentProductsTotal = 0.0
            updateGrandTotal()
        }

        fun setMode(paymentMode: Boolean) {
            isPaymentMode = paymentMode
            if (paymentMode) {
                layoutCredit.visibility = View.GONE
                layoutPayment.visibility = View.VISIBLE
                btnModePayment.setBackgroundColor(resources.getColor(R.color.soft_green, null))
                btnModePayment.setTextColor(resources.getColor(R.color.white, null))
                btnModeCredit.setBackgroundColor(resources.getColor(R.color.bg_light, null))
                btnModeCredit.setTextColor(resources.getColor(R.color.text_dark, null))
                btnSave.text = "পরিশোধ হিসেবে সংরক্ষণ করুন"
                btnSave.setBackgroundColor(resources.getColor(R.color.soft_green, null))
            } else {
                layoutCredit.visibility = View.VISIBLE
                layoutPayment.visibility = View.GONE
                btnModeCredit.setBackgroundColor(resources.getColor(R.color.warm_red, null))
                btnModeCredit.setTextColor(resources.getColor(R.color.white, null))
                btnModePayment.setBackgroundColor(resources.getColor(R.color.bg_light, null))
                btnModePayment.setTextColor(resources.getColor(R.color.text_dark, null))
                btnSave.text = "ধার হিসেবে সংরক্ষণ করুন"
                btnSave.setBackgroundColor(resources.getColor(R.color.warm_red, null))
            }
        }
        btnModeCredit.setOnClickListener { setMode(false) }
        btnModePayment.setOnClickListener { setMode(true) }

        fun loadForShop(shopId: Long) {
            productsJob?.cancel()
            productsJob = viewLifecycleOwner.lifecycleScope.launch {
                dao.getProductsByShop(shopId).collect { products ->
                    currentProducts = products
                    refreshProductAdapter()
                }
            }
            dueJob?.cancel()
            dueJob = viewLifecycleOwner.lifecycleScope.launch {
                dao.getShopSummaries().collect { summaries ->
                    val summary = summaries.find { it.shopId == shopId }
                    tvCurrentDue.text = "বর্তমান বাকি: ₹${summary?.due ?: 0.0}"
                }
            }
        }

        fun selectShop(shop: Shop) {
            currentShopId = shop.id
            tvSelectedShopName.text = shop.name
            tvSelectedShopName.setTextColor(resources.getColor(R.color.text_dark, null))
            ivSelectedShopIcon.setImageResource(IconMapper.getShopIcon(shop.name))
            loadForShop(shop.id)
        }

        rowSelectShop.setOnClickListener {
            ShopPickerBottomSheet { shop -> selectShop(shop) }
                .show(childFragmentManager, "shop_picker")
        }

        etManualAmount.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) { updateGrandTotal() }
        })

        btnSave.setOnClickListener {
            if (currentShopId == 0L) {
                Toast.makeText(context, "প্রথমে একটি দোকান নির্বাচন করুন", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (isPaymentMode) {
                val amount = etPaymentAmount.text.toString().toDoubleOrNull() ?: 0.0
                if (amount <= 0) {
                    Toast.makeText(context, "সঠিক পরিমাণ দিন", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                viewLifecycleOwner.lifecycleScope.launch {
                    val date = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(Date())
                    val time = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
                    val tx = Transaction(shopId = currentShopId, totalAmount = amount, type = "PAYMENT", dateString = date, timeString = time)
                    dao.insertTransaction(tx)
                    Toast.makeText(context, "পরিশোধ সংরক্ষণ হয়েছে!", Toast.LENGTH_SHORT).show()
                    etPaymentAmount.text.clear()
                }
            } else {
                val manualName = etManualName.text.toString().trim()
                val manualAmount = etManualAmount.text.toString().toDoubleOrNull() ?: 0.0
                val selectedProducts = (rvProducts.adapter as? QuickEntryProductAdapter)?.getSelectedItems() ?: emptyList()

                val totalAmount = selectedProducts.sumOf { it.subtotal } + manualAmount
                if (totalAmount <= 0) {
                    Toast.makeText(context, "অন্তত একটি পণ্যের পরিমাণ দিন বা ম্যানুয়াল টাকা লিখুন", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }

                viewLifecycleOwner.lifecycleScope.launch {
                    val date = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(Date())
                    val time = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
                    val tx = Transaction(shopId = currentShopId, totalAmount = totalAmount, type = "CREDIT", dateString = date, timeString = time)

                    val items = mutableListOf<TransactionItem>()
                    selectedProducts.forEach { sp ->
                        items.add(
                            TransactionItem(
                                transactionId = 0,
                                productId = sp.productId,
                                productNameSnapshot = sp.name,
                                unitPriceSnapshot = sp.unitPrice,
                                quantity = sp.quantity,
                                subtotal = sp.subtotal
                            )
                        )
                    }
                    if (manualName.isNotEmpty() && manualAmount > 0) {
                        items.add(
                            TransactionItem(
                                transactionId = 0,
                                productId = 0,
                                productNameSnapshot = manualName,
                                unitPriceSnapshot = manualAmount,
                                quantity = 1.0,
                                subtotal = manualAmount
                            )
                        )
                    }

                    dao.saveCreditEntry(tx, items)
                    Toast.makeText(context, "ধারের হিসাব সংরক্ষণ হয়েছে!", Toast.LENGTH_SHORT).show()

                    etManualName.text.clear()
                    etManualAmount.text.clear()
                }
            }
        }

        setMode(false)
    }
}
