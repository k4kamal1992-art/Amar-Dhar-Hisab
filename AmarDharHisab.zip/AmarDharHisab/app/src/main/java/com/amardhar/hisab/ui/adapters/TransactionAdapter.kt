package com.amardhar.hisab.ui.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.amardhar.hisab.R
import com.amardhar.hisab.data.Transaction

class TransactionAdapter(private var list: List<Transaction>) : 
    RecyclerView.Adapter<TransactionAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val shopName: TextView = view.findViewById(R.id.tv_shop_name)
        val dateTime: TextView = view.findViewById(R.id.tv_date_time)
        val amount: TextView = view.findViewById(R.id.tv_amount)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_transaction, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = list[position]
        holder.shopName.text = "দোকান ID: ${item.shopId}" // পরবর্তীতে নাম আনা হবে
        holder.dateTime.text = "${item.dateString} | ${item.timeString}"
        holder.amount.text = "₹ ${item.totalAmount}"
    }

    override fun getItemCount() = list.size

    fun updateList(newList: List<Transaction>) {
        list = newList
        notifyDataSetChanged()
    }
}