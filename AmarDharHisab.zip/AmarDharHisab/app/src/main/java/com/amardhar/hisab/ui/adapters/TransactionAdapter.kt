package com.amardhar.hisab.ui.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.amardhar.hisab.R
import com.amardhar.hisab.data.TransactionWithShop

class TransactionAdapter(
    private var list: List<TransactionWithShop>,
    private val onDeleteClick: ((TransactionWithShop) -> Unit)? = null,
    private val canDelete: (TransactionWithShop) -> Boolean = { false }
) : RecyclerView.Adapter<TransactionAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val shopName: TextView = view.findViewById(R.id.tv_shop_name)
        val typeBadge: TextView = view.findViewById(R.id.tv_type_badge)
        val dateTime: TextView = view.findViewById(R.id.tv_date_time)
        val amount: TextView = view.findViewById(R.id.tv_amount)
        val deleteBtn: View? = view.findViewById(R.id.btn_delete_tx)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_transaction, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val entry = list[position]
        val tx = entry.transaction
        val context = holder.itemView.context

        holder.shopName.text = entry.shopName
        holder.dateTime.text = "${tx.dateString} | ${tx.timeString}"

        if (tx.type == "CREDIT") {
            holder.typeBadge.text = "ধার"
            holder.typeBadge.setBackgroundColor(ContextCompat.getColor(context, R.color.warm_red))
            holder.amount.setTextColor(ContextCompat.getColor(context, R.color.warm_red))
        } else {
            holder.typeBadge.text = "পরিশোধ"
            holder.typeBadge.setBackgroundColor(ContextCompat.getColor(context, R.color.soft_green))
            holder.amount.setTextColor(ContextCompat.getColor(context, R.color.soft_green))
        }
        holder.amount.text = "₹ ${tx.totalAmount}"

        holder.deleteBtn?.visibility = if (canDelete(entry)) View.VISIBLE else View.GONE
        holder.deleteBtn?.setOnClickListener { onDeleteClick?.invoke(entry) }
    }

    override fun getItemCount() = list.size

    fun updateList(newList: List<TransactionWithShop>) {
        list = newList
        notifyDataSetChanged()
    }
}
