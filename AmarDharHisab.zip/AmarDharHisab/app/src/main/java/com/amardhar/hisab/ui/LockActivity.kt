package com.amardhar.hisab.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import com.amardhar.hisab.R
import com.amardhar.hisab.security.AppLockManager

/**
 * মোড ১ (setupMode=true): নতুন PIN সেট করা (দুইবার লিখতে হয়, মিলতে হবে)
 * মোড ২ (setupMode=false): বিদ্যমান PIN দিয়ে আনলক করা, ভুল হলে lockout প্রয়োগ
 */
class LockActivity : AppCompatActivity() {

    private lateinit var lockManager: AppLockManager
    private var enteredPin = StringBuilder()
    private var firstPinEntry: String? = null // setup মোডে প্রথমবার লেখা PIN মনে রাখার জন্য
    private var isSetupMode = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        lockManager = AppLockManager(this)
        isSetupMode = intent.getBooleanExtra("setup_mode", false)

        // PIN সেট করা না থাকলে এবং সেটআপ মোড না হলে সরাসরি মূল অ্যাপে চলে যাওয়া
        if (!isSetupMode && !lockManager.hasPin()) {
            proceedToApp()
            return
        }

        setContentView(R.layout.activity_lock)

        val tvTitle = findViewById<TextView>(R.id.tv_lock_title)
        val tvSubtitle = findViewById<TextView>(R.id.tv_lock_subtitle)
        val tvPinDisplay = findViewById<TextView>(R.id.tv_pin_display)
        val tvError = findViewById<TextView>(R.id.tv_lock_error)
        val btnFingerprint = findViewById<Button>(R.id.btn_fingerprint)

        if (isSetupMode) {
            tvTitle.text = "নতুন PIN সেট করুন"
            tvSubtitle.text = "৪ সংখ্যার একটি PIN দিন"
            btnFingerprint.visibility = android.view.View.INVISIBLE
        } else {
            tvTitle.text = "অ্যাপ আনলক করুন"
            tvSubtitle.text = "আপনার PIN দিন"
            checkLockoutState(tvError, tvSubtitle)
            if (lockManager.isBiometricEnabled()) {
                btnFingerprint.setOnClickListener { showBiometricPrompt() }
                showBiometricPrompt()
            } else {
                btnFingerprint.visibility = android.view.View.INVISIBLE
            }
        }

        val digitButtons = listOf(
            R.id.btn_0 to "0", R.id.btn_1 to "1", R.id.btn_2 to "2", R.id.btn_3 to "3",
            R.id.btn_4 to "4", R.id.btn_5 to "5", R.id.btn_6 to "6", R.id.btn_7 to "7",
            R.id.btn_8 to "8", R.id.btn_9 to "9"
        )
        digitButtons.forEach { (id, digit) ->
            findViewById<Button>(id).setOnClickListener {
                if (enteredPin.length < 4) {
                    enteredPin.append(digit)
                    tvPinDisplay.text = "●".repeat(enteredPin.length)
                    if (enteredPin.length == 4) {
                        onPinComplete(tvPinDisplay, tvError, tvSubtitle)
                    }
                }
            }
        }
        findViewById<Button>(R.id.btn_backspace).setOnClickListener {
            if (enteredPin.isNotEmpty()) {
                enteredPin.deleteCharAt(enteredPin.length - 1)
                tvPinDisplay.text = "●".repeat(enteredPin.length)
            }
        }
    }

    private fun checkLockoutState(tvError: TextView, tvSubtitle: TextView) {
        val remaining = lockManager.getLockoutRemainingMs()
        if (remaining > 0) {
            val seconds = (remaining / 1000) + 1
            tvError.text = "অনেকবার ভুল PIN দিয়েছেন। $seconds সেকেন্ড পর আবার চেষ্টা করুন।"
            tvError.visibility = android.view.View.VISIBLE
            setKeypadEnabled(false)
            findViewById<TextView>(R.id.tv_pin_display).postDelayed({
                setKeypadEnabled(true)
                tvError.visibility = android.view.View.INVISIBLE
            }, remaining)
        }
    }

    private fun setKeypadEnabled(enabled: Boolean) {
        val ids = listOf(
            R.id.btn_0, R.id.btn_1, R.id.btn_2, R.id.btn_3, R.id.btn_4,
            R.id.btn_5, R.id.btn_6, R.id.btn_7, R.id.btn_8, R.id.btn_9, R.id.btn_backspace
        )
        ids.forEach { findViewById<Button>(it).isEnabled = enabled }
    }

    private fun onPinComplete(tvPinDisplay: TextView, tvError: TextView, tvSubtitle: TextView) {
        if (isSetupMode) {
            if (firstPinEntry == null) {
                firstPinEntry = enteredPin.toString()
                enteredPin.clear()
                tvPinDisplay.text = ""
                tvSubtitle.text = "আবার একই PIN লিখুন (নিশ্চিত করার জন্য)"
            } else {
                if (firstPinEntry == enteredPin.toString()) {
                    lockManager.setPin(enteredPin.toString())
                    setResult(RESULT_OK)
                    finish()
                } else {
                    tvError.text = "PIN দুটি মেলেনি। আবার চেষ্টা করুন।"
                    tvError.visibility = android.view.View.VISIBLE
                    firstPinEntry = null
                    enteredPin.clear()
                    tvPinDisplay.text = ""
                    tvSubtitle.text = "৪ সংখ্যার একটি PIN দিন"
                }
            }
        } else {
            if (lockManager.verifyPin(enteredPin.toString())) {
                proceedToApp()
            } else {
                enteredPin.clear()
                tvPinDisplay.text = ""
                val remaining = lockManager.getLockoutRemainingMs()
                if (remaining > 0) {
                    checkLockoutState(tvError, tvSubtitle)
                } else {
                    tvError.text = "ভুল PIN। আবার চেষ্টা করুন।"
                    tvError.visibility = android.view.View.VISIBLE
                }
            }
        }
    }

    private fun showBiometricPrompt() {
        val biometricManager = BiometricManager.from(this)
        if (biometricManager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) != BiometricManager.BIOMETRIC_SUCCESS) {
            return
        }
        val executor = ContextCompat.getMainExecutor(this)
        val prompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                super.onAuthenticationSucceeded(result)
                proceedToApp()
            }
        })
        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle("আঙুলের ছাপ দিয়ে আনলক করুন")
            .setNegativeButtonText("PIN ব্যবহার করুন")
            .build()
        prompt.authenticate(promptInfo)
    }

    private fun proceedToApp() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
