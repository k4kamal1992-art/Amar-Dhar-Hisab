package com.amardhar.hisab.ui.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.amardhar.hisab.R
import com.amardhar.hisab.data.Product

class ProductAdapter(
    private var list: List<Product>,
    private val onDeleteClick: (Product) -> Unit,
    private val onClick: ((Product) -> Unit)? = null
) : RecyclerView.Adapter<ProductAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val name: TextView = view.findViewById(R.id.tv_product_name)
        val price: TextView = view.findViewById(R.id.tv_product_price)
        val deleteBtn: View = view.findViewById(R.id.btn_delete_product)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_product, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = list[position]
        holder.name.text = item.name
        holder.price.text = "₹ ${item.price}"
        holder.deleteBtn.setOnClickListener { onDeleteClick(item) }
        holder.itemView.setOnClickListener { onClick?.invoke(item) }
    }

    override fun getItemCount() = list.size

    fun updateList(newList: List<Product>) {
        list = newList
        notifyDataSetChanged()
    }
}
