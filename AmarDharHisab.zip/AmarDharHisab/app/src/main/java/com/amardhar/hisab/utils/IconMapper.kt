package com.amardhar.hisab.utils

import com.amardhar.hisab.R

/**
 * পণ্য বা দোকানের নাম (বাংলা) দেখে সবচেয়ে কাছাকাছি আইকন খুঁজে বের করে।
 * কোনো মিল না পেলে একটি সাধারণ (fallback) আইকন ব্যবহার হয় — কখনো broken image দেখাবে না।
 */
object IconMapper {

    // (কীওয়ার্ডসমূহ, drawable resource) — উপরের দিকের এন্ট্রি আগে চেক হয়
    private val productKeywordMap: List<Pair<List<String>, Int>> = listOf(
        listOf("চা পাতা", "চা") to R.drawable.tea,
        listOf("দুধ চা") to R.drawable.milk_tea,
        listOf("রং চা", "লিকার চা") to R.drawable.black_tea,
        listOf("কফি") to R.drawable.coffee,
        listOf("বিস্কুট") to R.drawable.biscuit,
        listOf("কুকিজ") to R.drawable.cookies,
        listOf("টোস্ট") to R.drawable.toast,
        listOf("পাউরুটি", "রুটি", "ব্রেড") to R.drawable.bread,
        listOf("কেক") to R.drawable.cake,
        listOf("চকোলেট", "চকলেট") to R.drawable.chocolate,
        listOf("লাড্ডু", "লাডডু") to R.drawable.laddu,
        listOf("রসগোল্লা") to R.drawable.rasgulla,
        listOf("সন্দেশ") to R.drawable.sandesh,
        listOf("মিষ্টি দই", "দই") to R.drawable.mishti_doi,
        listOf("জিলাপি", "জিলাপী") to R.drawable.jalebi,
        listOf("মিষ্টি") to R.drawable.sweet,
        listOf("লজেন্স", "লিচেন্স", "লজেন্স") to R.drawable.lollipop,
        listOf("চুইংগাম", "গাম") to R.drawable.gum,
        listOf("চানাচুর") to R.drawable.chanachur,
        listOf("চিপস") to R.drawable.chips,
        listOf("ক্যান্ডি") to R.drawable.candy,
        listOf("জুস") to R.drawable.juice,
        listOf("কোল্ড ড্রিংক", "ঠান্ডা পানীয়", "কোমল পানীয়") to R.drawable.cold_drink,
        listOf("পানির বোতল", "মিনারেল ওয়াটার") to R.drawable.water_bottle,
        listOf("বিড়ি") to R.drawable.bidi,
        listOf("সিগারেট") to R.drawable.cigarette,
        listOf("দিয়াশলাই", "ম্যাচ") to R.drawable.matchbox,
        listOf("লাইটার") to R.drawable.lighter,
        listOf("নুডলস") to R.drawable.noodles,
        listOf("সুজি") to R.drawable.suji,
        listOf("ময়দা") to R.drawable.maida,
        listOf("আটা") to R.drawable.atta,
        listOf("গুড়া দুধ", "গুঁড়া দুধ", "পাউডার দুধ") to R.drawable.milk_powder,
        listOf("দুধ") to R.drawable.milk_packet,
        listOf("চিনি") to R.drawable.sugar,
        listOf("লবণ", "লবন") to R.drawable.salt,
        listOf("সয়াবিন তেল") to R.drawable.soybean_oil,
        listOf("সরিষার তেল", "সরষের তেল") to R.drawable.mustard_oil,
        listOf("তেল") to R.drawable.oil,
        listOf("মসুর ডাল") to R.drawable.masoor_dal,
        listOf("মুগ ডাল") to R.drawable.moong_dal,
        listOf("ছোলার ডাল", "চানার ডাল") to R.drawable.chana_dal,
        listOf("ডাল") to R.drawable.dal,
        listOf("মরিচ গুঁড়া", "মরিচ গুড়া", "মরিচের গুঁড়া") to R.drawable.chilli_powder,
        listOf("হলুদ গুঁড়া", "হলুদ গুড়া", "হলুদ") to R.drawable.turmeric,
        listOf("ধনিয়া গুঁড়া", "ধনে গুঁড়া") to R.drawable.coriander_powder,
        listOf("জিরা") to R.drawable.cumin,
        listOf("গরম মসলা") to R.drawable.garam_masala,
        listOf("মসলা") to R.drawable.spices,
        listOf("সেমাই") to R.drawable.vermicelli,
        listOf("চাল", "মিনিকেট", "নাজিরশাইল") to R.drawable.rice,
        listOf("সাবান") to R.drawable.soap,
        listOf("গোসলের সাবান") to R.drawable.body_soap,
        listOf("শ্যাম্পু") to R.drawable.shampoo,
        listOf("টুথপেস্ট") to R.drawable.toothpaste,
        listOf("টুথব্রাশ", "ব্রাশ") to R.drawable.toothbrush,
        listOf("ডিটারজেন্ট", "কাপড় কাচার সাবান") to R.drawable.detergent,
        listOf("ওয়াশিং পাউডার") to R.drawable.washing_powder,
        listOf("বাসন মাজার সাবান", "ডিশওয়াশ") to R.drawable.dishwash,
        listOf("টয়লেট ক্লিনার") to R.drawable.toilet_cleaner,
        listOf("টিস্যু") to R.drawable.tissue,
        listOf("মোমবাতি") to R.drawable.candle,
        listOf("মশার কয়েল", "কয়েল") to R.drawable.mosquito_coil,
        listOf("চুলের তেল") to R.drawable.hair_oil,
        listOf("আগরবাতি", "ধূপকাঠি") to R.drawable.incense_stick,
        listOf("ব্যাটারি") to R.drawable.battery,
        listOf("খাতা", "নোটবুক") to R.drawable.notebook,
        listOf("কাগজ") to R.drawable.paper,
        listOf("কলম", "বলপয়েন্ট") to R.drawable.pen,
        listOf("পেন্সিল") to R.drawable.pencil,
        listOf("রাবার") to R.drawable.eraser,
        listOf("কাটার", "শার্পনার") to R.drawable.sharpener,

        // সবজি
        listOf("আলু") to R.drawable.potato,
        listOf("মিষ্টি আলু") to R.drawable.sweet_potato,
        listOf("পেঁয়াজ", "পিয়াজ") to R.drawable.onion,
        listOf("রসুন") to R.drawable.garlic,
        listOf("আদা") to R.drawable.ginger,
        listOf("টমেটো") to R.drawable.tomato,
        listOf("বেগুন") to R.drawable.brinjal,
        listOf("ঢেঁড়স", "ঢেঁড়শ") to R.drawable.okra,
        listOf("কুমড়া", "মিষ্টি কুমড়া") to R.drawable.pumpkin,
        listOf("ফুলকপি") to R.drawable.cauliflower,
        listOf("বাঁধাকপি") to R.drawable.cabbage,
        listOf("গাজর") to R.drawable.carrot,
        listOf("মুলা", "মূলা") to R.drawable.radish,
        listOf("করলা") to R.drawable.bitter_gourd,
        listOf("লাউ") to R.drawable.bottle_gourd,
        listOf("ঝিঙা", "ঝিঙে") to R.drawable.ridge_gourd,
        listOf("চিচিঙ্গা") to R.drawable.snake_gourd,
        listOf("সজনে ডাটা", "সজনে") to R.drawable.drumstick,
        listOf("কচি পেঁপে", "পেঁপে") to R.drawable.green_papaya,
        listOf("কাঁচকলা") to R.drawable.raw_banana,
        listOf("পুদিনা") to R.drawable.mint,
        listOf("মাশরুম") to R.drawable.mushroom,
        listOf("শিম") to R.drawable.beans,
        listOf("মটরশুটি", "মটর") to R.drawable.peas,
        listOf("ক্যাপসিকাম") to R.drawable.capsicum,
        listOf("ভুট্টা") to R.drawable.corn,
        listOf("বিট") to R.drawable.beetroot,
        listOf("পটল") to R.drawable.pointed_gourd,
        listOf("পালং শাক", "পালং") to R.drawable.spinach,
        listOf("লাল শাক") to R.drawable.spinach,
        listOf("ধনেপাতা", "ধনিয়া পাতা") to R.drawable.coriander,
        listOf("কাঁচা মরিচ") to R.drawable.green_chilli,
        listOf("লেবু") to R.drawable.lemon,
        listOf("শসা") to R.drawable.cucumber
    )

    private val shopKeywordMap: List<Pair<List<String>, Int>> = listOf(
        listOf("চা", "টি স্টল", "টিস্টল") to R.drawable.tea_shop,
        listOf("সবজি") to R.drawable.vegetable_shop,
        listOf("মিষ্টি") to R.drawable.sweet_shop,
        listOf("বেকারি", "বেকারী") to R.drawable.bakery_shop,
        listOf("স্টেশনারি", "স্টেশনারী") to R.drawable.stationery_shop,
        listOf("মুদি", "ভাণ্ডার", "ভান্ডার", "মুদী") to R.drawable.grocery_shop
    )

    fun getProductIcon(productName: String): Int {
        val name = productName.trim()
        if (name.isEmpty()) return R.drawable.ic_default_item
        for ((keywords, res) in productKeywordMap) {
            if (keywords.any { name.contains(it, ignoreCase = true) }) return res
        }
        return R.drawable.ic_default_item
    }

    fun getShopIcon(shopName: String): Int {
        val name = shopName.trim()
        if (name.isEmpty()) return R.drawable.general_store
        for ((keywords, res) in shopKeywordMap) {
            if (keywords.any { name.contains(it, ignoreCase = true) }) return res
        }
        return R.drawable.general_store
    }
}
