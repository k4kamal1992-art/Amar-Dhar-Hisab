package com.amardhar.hisab.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction as RoomTransaction
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {
    // ===== দোকান সংক্রান্ত =====
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertShop(shop: Shop)

    @Query("SELECT * FROM shops WHERE is_archived = 0")
    fun getAllShops(): Flow<List<Shop>>

    @Query("SELECT * FROM shops WHERE id = :shopId LIMIT 1")
    suspend fun getShopById(shopId: Long): Shop?

    // প্রতিটি দোকানের মোট ধার, মোট পরিশোধ ও বাকি
    @Query(
        """
        SELECT s.id AS shopId, s.name AS shopName, s.owner_name AS ownerName,
        COALESCE((SELECT SUM(total_amount) FROM transactions WHERE shop_id = s.id AND type = 'CREDIT'), 0) AS totalCredit,
        COALESCE((SELECT SUM(total_amount) FROM transactions WHERE shop_id = s.id AND type = 'PAYMENT'), 0) AS totalPayment
        FROM shops s
        WHERE s.is_archived = 0
        ORDER BY s.name ASC
        """
    )
    fun getShopSummaries(): Flow<List<ShopSummary>>

    // ===== পণ্য সংক্রান্ত =====
    @Insert
    suspend fun insertProductRaw(product: Product): Long

    @Insert
    suspend fun insertPriceHistory(history: ProductPriceHistory)

    // নতুন পণ্য যোগ করার সাথে সাথে তার প্রথম দামও ইতিহাসে রাখা হয়
    @RoomTransaction
    suspend fun insertProduct(product: Product, dateString: String): Long {
        val productId = insertProductRaw(product)
        insertPriceHistory(ProductPriceHistory(productId = productId, price = product.price, dateString = dateString))
        return productId
    }

    @Query("UPDATE products SET price = :newPrice WHERE id = :productId")
    suspend fun updateProductPriceRaw(productId: Long, newPrice: Double)

    // দাম পরিবর্তন করলে পুরনো লেনদেনের দাম অপরিবর্তিত থাকে, শুধু নতুন দাম ইতিহাসে যোগ হয়
    @RoomTransaction
    suspend fun updateProductPrice(productId: Long, newPrice: Double, dateString: String) {
        updateProductPriceRaw(productId, newPrice)
        insertPriceHistory(ProductPriceHistory(productId = productId, price = newPrice, dateString = dateString))
    }

    @Query("SELECT * FROM products WHERE shop_id = :shopId ORDER BY name ASC")
    fun getProductsByShop(shopId: Long): Flow<List<Product>>

    @Query("SELECT * FROM product_price_history WHERE product_id = :productId ORDER BY changed_at DESC")
    fun getPriceHistoryForProduct(productId: Long): Flow<List<ProductPriceHistory>>

    @Delete
    suspend fun deleteProduct(product: Product)

    // ===== ধার/পরিশোধের হিসাব ও স্ন্যাপশট লজিক (সবচেয়ে গুরুত্বপূর্ণ) =====
    @RoomTransaction
    suspend fun saveCreditEntry(tx: Transaction, items: List<TransactionItem>) {
        val txId = insertTransaction(tx)
        val itemsWithId = items.map { it.copy(transactionId = txId) }
        insertTransactionItems(itemsWithId)
    }

    @Insert
    suspend fun insertTransaction(tx: Transaction): Long

    @Insert
    suspend fun insertTransactionItems(items: List<TransactionItem>)

    @Query("SELECT * FROM transaction_items WHERE transaction_id = :transactionId")
    suspend fun getItemsForTransaction(transactionId: Long): List<TransactionItem>

    @Query("SELECT * FROM transactions ORDER BY timestamp DESC")
    fun getAllTransactions(): Flow<List<Transaction>>

    @Query(
        """
        SELECT t.*, s.name AS shopName FROM transactions t
        INNER JOIN shops s ON s.id = t.shop_id
        ORDER BY t.timestamp DESC
        """
    )
    fun getAllTransactionsWithShop(): Flow<List<TransactionWithShop>>

    @Query(
        """
        SELECT t.*, s.name AS shopName FROM transactions t
        INNER JOIN shops s ON s.id = t.shop_id
        ORDER BY t.timestamp DESC
        LIMIT :limit
        """
    )
    fun getRecentTransactionsWithShop(limit: Int): Flow<List<TransactionWithShop>>

    // ডিলিট করার নিয়ম: শুধুমাত্র আজকের হিসাব (তারিখ যাচাই Fragment স্তরে করা হয়)
    @Delete
    suspend fun deleteTransaction(tx: Transaction)

    @Query("DELETE FROM transaction_items WHERE transaction_id = :transactionId")
    suspend fun deleteItemsForTransactionId(transactionId: Long)

    @RoomTransaction
    suspend fun deleteTransactionWithItems(tx: Transaction) {
        deleteItemsForTransactionId(tx.id)
        deleteTransaction(tx)
    }
}
