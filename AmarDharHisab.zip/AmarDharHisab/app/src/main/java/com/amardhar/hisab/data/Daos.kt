package com.amardhar.hisab.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction as RoomTransaction
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {
    // দোকান সংক্রান্ত
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertShop(shop: Shop)

    @Query("SELECT * FROM shops WHERE is_archived = 0")
    fun getAllShops(): Flow<List<Shop>>

    // পণ্য সংক্রান্ত
    @Insert
    suspend fun insertProduct(product: Product)

    @Query("SELECT * FROM products WHERE shop_id = :shopId")
    fun getProductsByShop(shopId: Long): Flow<List<Product>>

    // ধারের হিসাব ও স্ন্যাপশট লজিক (সবচেয়ে গুরুত্বপূর্ণ)
    @RoomTransaction
    suspend fun saveCreditEntry(tx: Transaction, items: List<TransactionItem>) {
        val txId = insertTransaction(tx)
        val itemsWithId = items.map { it.copy(transactionId = txId) }
        insertTransactionItems(itemsWithId)
    }

    @Insert
    suspend fun insertTransaction(tx: Transaction): Long

    @Insert
    suspend fun insertTransactionItems(items: List<TransactionItem>)

    @Query("SELECT * FROM transactions ORDER BY timestamp DESC")
    fun getAllTransactions(): Flow<List<Transaction>>

    // ডিলিট করার নিয়ম: শুধুমাত্র আজকের হিসাব
    @Delete
    suspend fun deleteTransaction(tx: Transaction)
}