package com.amardhar.hisab

import android.app.Application
import com.amardhar.hisab.data.AppDatabase

class AmarDharApp : Application() {
    // ডাটাবেস ইন্সট্যান্স তৈরি
    val database by lazy { AppDatabase.getDatabase(this) }
}