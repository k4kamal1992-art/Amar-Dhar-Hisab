package com.amardhar.hisab.data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * একটি দোকান/কাস্টমারের তথ্য
 */
@Entity(tableName = "shops")
data class Shop(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,

    @ColumnInfo(name = "name")
    val name: String,

    @ColumnInfo(name = "owner_name")
    val ownerName: String = "",

    @ColumnInfo(name = "is_archived")
    val isArchived: Boolean = false
)

/**
 * একটি দোকানের অধীনে থাকা পণ্য (ভবিষ্যতে ব্যবহারের জন্য)
 */
@Entity(tableName = "products")
data class Product(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,

    @ColumnInfo(name = "shop_id")
    val shopId: Long,

    @ColumnInfo(name = "name")
    val name: String,

    @ColumnInfo(name = "price")
    val price: Double = 0.0
)

/**
 * একটি লেনদেন (ধার দেওয়া বা পরিশোধ)
 */
@Entity(tableName = "transactions")
data class Transaction(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,

    @ColumnInfo(name = "shop_id")
    val shopId: Long,

    @ColumnInfo(name = "total_amount")
    val totalAmount: Double,

    // "CREDIT" (ধার দেওয়া হয়েছে) বা "PAYMENT" (পরিশোধ হয়েছে)
    @ColumnInfo(name = "type")
    val type: String,

    @ColumnInfo(name = "date_string")
    val dateString: String,

    @ColumnInfo(name = "time_string")
    val timeString: String,

    @ColumnInfo(name = "timestamp")
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * একটি পণ্যের দামের ইতিহাস — দাম কখন পরিবর্তন হয়েছে তার রেকর্ড
 */
@Entity(tableName = "product_price_history")
data class ProductPriceHistory(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,

    @ColumnInfo(name = "product_id")
    val productId: Long,

    @ColumnInfo(name = "price")
    val price: Double,

    @ColumnInfo(name = "changed_at")
    val changedAt: Long = System.currentTimeMillis(),

    @ColumnInfo(name = "date_string")
    val dateString: String
)

/**
 * একটি লেনদেনের ভেতরের আইটেম (প্রতিটি পণ্যের স্ন্যাপশট)
 */
@Entity(tableName = "transaction_items")
data class TransactionItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,

    @ColumnInfo(name = "transaction_id")
    val transactionId: Long,

    @ColumnInfo(name = "product_id")
    val productId: Long,

    @ColumnInfo(name = "product_name_snapshot")
    val productNameSnapshot: String,

    @ColumnInfo(name = "unit_price_snapshot")
    val unitPriceSnapshot: Double,

    @ColumnInfo(name = "quantity")
    val quantity: Double,

    @ColumnInfo(name = "subtotal")
    val subtotal: Double
)
