package com.amardhar.hisab.ui.fragments

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.amardhar.hisab.R
import com.amardhar.hisab.AmarDharApp
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch

class HomeFragment : Fragment(R.layout.fragment_home) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        val tvBalance = view.findViewById<TextView>(R.id.tv_total_balance)
        val app = requireActivity().application as AmarDharApp

        // ডাটাবেস থেকে হিসাব আনা
        MainScope().launch {
            app.database.appDao().getAllTransactions().collect { list ->
                var total = 0.0
                list.forEach { 
                    if(it.type == "CREDIT") total += it.totalAmount
                    else total -= it.totalAmount
                }
                tvBalance.text = "₹ $total"
            }
        }
    }
}