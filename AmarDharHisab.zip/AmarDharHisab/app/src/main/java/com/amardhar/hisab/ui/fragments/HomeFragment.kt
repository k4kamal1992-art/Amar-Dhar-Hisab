package com.amardhar.hisab.ui.fragments

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.amardhar.hisab.R
import com.amardhar.hisab.AmarDharApp
import com.amardhar.hisab.ui.adapters.ShopSummaryAdapter
import com.amardhar.hisab.ui.adapters.TransactionAdapter
import androidx.navigation.fragment.findNavController
import kotlinx.coroutines.launch

class HomeFragment : Fragment(R.layout.fragment_home) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val app = requireActivity().application as AmarDharApp
        val dao = app.database.appDao()

        val tvTotalCredit = view.findViewById<TextView>(R.id.tv_total_credit)
        val tvTotalPayment = view.findViewById<TextView>(R.id.tv_total_payment)
        val tvBalance = view.findViewById<TextView>(R.id.tv_total_balance)
        val tvShopCount = view.findViewById<TextView>(R.id.tv_shop_count)

        val rvShops = view.findViewById<RecyclerView>(R.id.rv_shops_summary)
        rvShops.layoutManager = LinearLayoutManager(context)
        val shopAdapter = ShopSummaryAdapter(emptyList()) { summary ->
            val action = HomeFragmentDirections.actionNavHomeToShopDetail(summary.shopId, summary.shopName)
            findNavController().navigate(action)
        }
        rvShops.adapter = shopAdapter

        val rvRecent = view.findViewById<RecyclerView>(R.id.rv_recent_transactions)
        rvRecent.layoutManager = LinearLayoutManager(context)
        val recentAdapter = TransactionAdapter(emptyList())
        rvRecent.adapter = recentAdapter

        // দোকানভিত্তিক সারসংক্ষেপ থেকে মোট ধার/পরিশোধ/বাকি হিসাব
        viewLifecycleOwner.lifecycleScope.launch {
            dao.getShopSummaries().collect { summaries ->
                shopAdapter.updateList(summaries)
                tvShopCount.text = "মোট দোকান: ${summaries.size}"

                val totalCredit = summaries.sumOf { it.totalCredit }
                val totalPayment = summaries.sumOf { it.totalPayment }
                tvTotalCredit.text = "₹ $totalCredit"
                tvTotalPayment.text = "₹ $totalPayment"
                tvBalance.text = "₹ ${totalCredit - totalPayment}"
            }
        }

        viewLifecycleOwner.lifecycleScope.launch {
            dao.getRecentTransactionsWithShop(5).collect { recentAdapter.updateList(it) }
        }
    }
}
