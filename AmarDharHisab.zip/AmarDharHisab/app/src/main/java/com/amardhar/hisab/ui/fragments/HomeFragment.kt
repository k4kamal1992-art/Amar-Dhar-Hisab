package com.amardhar.hisab.ui.fragments

import android.app.DatePickerDialog
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.AdapterView
import android.widget.Spinner
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.amardhar.hisab.R
import com.amardhar.hisab.AmarDharApp
import com.amardhar.hisab.ui.adapters.ShopSummaryAdapter
import com.amardhar.hisab.ui.adapters.TransactionAdapter
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.util.Calendar

class HomeFragment : Fragment(R.layout.fragment_home) {

    private var summaryJob: Job? = null

    private val periodOptions = listOf(
        "গত ৭ দিন", "গত ১৫ দিন", "গত ৩০ দিন", "গত ৩ মাস", "এই বছর", "কাস্টম সময়"
    )
    private var customStart: Long? = null
    private var customEnd: Long? = null

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val app = requireActivity().application as AmarDharApp
        val dao = app.database.appDao()

        val tvTotalCredit = view.findViewById<TextView>(R.id.tv_total_credit)
        val tvTotalPayment = view.findViewById<TextView>(R.id.tv_total_payment)
        val tvBalance = view.findViewById<TextView>(R.id.tv_total_balance)
        val tvShopCount = view.findViewById<TextView>(R.id.tv_shop_count)
        val spinnerPeriod = view.findViewById<Spinner>(R.id.spinner_period)

        val rvShops = view.findViewById<RecyclerView>(R.id.rv_shops_summary)
        rvShops.layoutManager = LinearLayoutManager(context)
        val shopAdapter = ShopSummaryAdapter(emptyList()) { summary ->
            val action = HomeFragmentDirections.actionNavHomeToShopDetail(summary.shopId, summary.shopName)
            findNavController().navigate(action)
        }
        rvShops.adapter = shopAdapter

        val rvRecent = view.findViewById<RecyclerView>(R.id.rv_recent_transactions)
        rvRecent.layoutManager = LinearLayoutManager(context)
        val recentAdapter = TransactionAdapter(emptyList())
        rvRecent.adapter = recentAdapter

        // দোকানভিত্তিক বর্তমান বাকি — সবসময় সর্বকালের real balance, কোনো date filter প্রভাব ফেলে না
        viewLifecycleOwner.lifecycleScope.launch {
            dao.getShopSummaries().collect { summaries ->
                shopAdapter.updateList(summaries)
                tvShopCount.text = "মোট দোকান: ${summaries.size}"
                val totalCreditAllTime = summaries.sumOf { it.totalCredit }
                val totalPaymentAllTime = summaries.sumOf { it.totalPayment }
                tvBalance.text = "₹ ${totalCreditAllTime - totalPaymentAllTime}"
            }
        }

        viewLifecycleOwner.lifecycleScope.launch {
            dao.getRecentTransactionsWithShop(5).collect { recentAdapter.updateList(it) }
        }

        // সময়ের ফিল্টার — শুধু উপরের দুই কার্ডের (মোট ধার/পরিশোধ) সংখ্যা পরিবর্তন করবে
        val spinnerAdapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, periodOptions)
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerPeriod.adapter = spinnerAdapter

        fun loadForRange(start: Long, end: Long) {
            summaryJob?.cancel()
            summaryJob = viewLifecycleOwner.lifecycleScope.launch {
                dao.getTransactionsBetween(start, end).collect { txs ->
                    val credit = txs.filter { it.type == "CREDIT" }.sumOf { it.totalAmount }
                    val payment = txs.filter { it.type == "PAYMENT" }.sumOf { it.totalAmount }
                    tvTotalCredit.text = "₹ $credit"
                    tvTotalPayment.text = "₹ $payment"
                }
            }
        }

        fun applyPeriod(position: Int) {
            val now = Calendar.getInstance()
            val end = now.timeInMillis
            val cal = Calendar.getInstance()

            when (position) {
                0 -> cal.add(Calendar.DAY_OF_YEAR, -7)
                1 -> cal.add(Calendar.DAY_OF_YEAR, -15)
                2 -> cal.add(Calendar.DAY_OF_YEAR, -30)
                3 -> cal.add(Calendar.MONTH, -3)
                4 -> {
                    cal.set(Calendar.DAY_OF_YEAR, 1)
                    cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0)
                }
                5 -> {
                    // কাস্টম সময় — দুইটা DatePicker দিয়ে ব্যবহারকারী নিজে বেছে নেবেন
                    pickCustomRange { start, endCustom ->
                        customStart = start
                        customEnd = endCustom
                        loadForRange(start, endCustom)
                    }
                    return
                }
            }
            loadForRange(cal.timeInMillis, end)
        }

        spinnerPeriod.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, v: View?, position: Int, id: Long) {
                applyPeriod(position)
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        // ডিফল্ট: গত ৭ দিন (spinner এর প্রথম আইটেম নির্বাচিত থাকায় onItemSelected এমনিতেই কল হবে)
    }

    private fun pickCustomRange(onPicked: (start: Long, end: Long) -> Unit) {
        val calStart = Calendar.getInstance()
        DatePickerDialog(requireContext(), { _, y, m, d ->
            calStart.set(y, m, d, 0, 0, 0)
            val calEnd = Calendar.getInstance()
            DatePickerDialog(requireContext(), { _, y2, m2, d2 ->
                calEnd.set(y2, m2, d2, 23, 59, 59)
                onPicked(calStart.timeInMillis, calEnd.timeInMillis)
            }, calEnd.get(Calendar.YEAR), calEnd.get(Calendar.MONTH), calEnd.get(Calendar.DAY_OF_MONTH)).show()
        }, calStart.get(Calendar.YEAR), calStart.get(Calendar.MONTH), calStart.get(Calendar.DAY_OF_MONTH)).show()
    }
}
