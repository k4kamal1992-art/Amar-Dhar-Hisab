package com.amardhar.hisab.ui.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.amardhar.hisab.AmarDharApp
import com.amardhar.hisab.R
import com.amardhar.hisab.data.Shop
import com.amardhar.hisab.ui.adapters.ShopSummaryAdapter
import com.google.android.material.floatingactionbutton.FloatingActionButton
import kotlinx.coroutines.launch

class ShopFragment : Fragment(R.layout.fragment_shop) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val app = requireActivity().application as AmarDharApp
        val dao = app.database.appDao()

        val rv = view.findViewById<RecyclerView>(R.id.rv_shops)
        rv.layoutManager = LinearLayoutManager(context)
        val adapter = ShopSummaryAdapter(emptyList()) { shopSummary ->
            val action = ShopFragmentDirections.actionNavShopsToShopDetail(shopSummary.shopId, shopSummary.shopName)
            findNavController().navigate(action)
        }
        rv.adapter = adapter

        viewLifecycleOwner.lifecycleScope.launch {
            dao.getShopSummaries().collect { adapter.updateList(it) }
        }

        val fab = view.findViewById<FloatingActionButton>(R.id.fab_add_shop)
        fab.setOnClickListener { showAddShopDialog(dao) }
    }

    private fun showAddShopDialog(dao: com.amardhar.hisab.data.AppDao) {
        val dialogView = LayoutInflater.from(context).inflate(R.layout.dialog_add_shop, null)
        val etName = dialogView.findViewById<EditText>(R.id.et_dialog_shop_name)
        val etOwner = dialogView.findViewById<EditText>(R.id.et_dialog_owner_name)

        AlertDialog.Builder(requireContext())
            .setTitle("নতুন দোকান যোগ করুন")
            .setView(dialogView)
            .setPositiveButton("সেভ করুন") { _, _ ->
                val name = etName.text.toString().trim()
                if (name.isEmpty()) {
                    Toast.makeText(context, "দোকানের নাম দিন", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                viewLifecycleOwner.lifecycleScope.launch {
                    dao.insertShop(Shop(name = name, ownerName = etOwner.text.toString().trim()))
                    Toast.makeText(context, "দোকান যোগ হয়েছে", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("বাতিল", null)
            .show()
    }
}
