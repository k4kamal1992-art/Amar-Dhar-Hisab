package com.amardhar.hisab.ui.fragments

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.amardhar.hisab.AmarDharApp
import com.amardhar.hisab.R
import com.amardhar.hisab.data.Shop
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch

class ShopFragment : Fragment(R.layout.fragment_shop) {
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val etName = view.findViewById<EditText>(R.id.et_shop_name)
        val etOwner = view.findViewById<EditText>(R.id.et_owner_name)
        val btnSave = view.findViewById<Button>(R.id.btn_save_shop)
        val dao = (requireActivity().application as AmarDharApp).database.appDao()

        btnSave.setOnClickListener {
            val name = etName.text.toString()
            if (name.isNotEmpty()) {
                MainScope().launch {
                    dao.insertShop(Shop(name = name, ownerName = etOwner.text.toString()))
                    Toast.makeText(context, "দোকান সেভ হয়েছে!", Toast.LENGTH_SHORT).show()
                    etName.text.clear()
                    etOwner.text.clear()
                }
            } else {
                Toast.makeText(context, "নাম দিন", Toast.LENGTH_SHORT).show()
            }
        }
    }
}