package com.amardhar.hisab.ui.fragments

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.amardhar.hisab.AmarDharApp
import com.amardhar.hisab.R
import com.amardhar.hisab.data.TransactionWithShop
import com.amardhar.hisab.ui.adapters.TransactionAdapter
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HistoryFragment : Fragment(R.layout.fragment_history) {

    private var allTransactions: List<TransactionWithShop> = emptyList()
    private var typeFilter: String? = null // null = সব, "CREDIT", "PAYMENT"

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val app = requireActivity().application as AmarDharApp
        val dao = app.database.appDao()
        val todayStr = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(Date())

        val rv = view.findViewById<RecyclerView>(R.id.rv_history)
        rv.layoutManager = LinearLayoutManager(context)
        val etSearch = view.findViewById<EditText>(R.id.et_search_history)
        val btnAll = view.findViewById<Button>(R.id.btn_filter_all)
        val btnCredit = view.findViewById<Button>(R.id.btn_filter_credit)
        val btnPayment = view.findViewById<Button>(R.id.btn_filter_payment)

        fun showDetailDialog(entry: TransactionWithShop) {
            viewLifecycleOwner.lifecycleScope.launch {
                val tx = entry.transaction
                val typeLabel = if (tx.type == "CREDIT") "ধার" else "পরিশোধ"
                val sb = StringBuilder()
                sb.append("দোকান: ${entry.shopName}\n")
                sb.append("তারিখ: ${tx.dateString} | সময়: ${tx.timeString}\n")
                sb.append("ধরন: $typeLabel\n")
                sb.append("মোট পরিমাণ: ₹${tx.totalAmount}\n")

                if (tx.type == "CREDIT") {
                    val items = dao.getItemsForTransaction(tx.id)
                    if (items.isNotEmpty()) {
                        sb.append("\nপণ্যের বিবরণ:\n")
                        items.forEach { item ->
                            sb.append("• ${item.productNameSnapshot} — ${item.quantity} x ₹${item.unitPriceSnapshot} = ₹${item.subtotal}\n")
                        }
                    }
                }

                AlertDialog.Builder(requireContext())
                    .setTitle("লেনদেনের বিস্তারিত")
                    .setMessage(sb.toString())
                    .setPositiveButton("বন্ধ করুন", null)
                    .show()
            }
        }

        lateinit var adapter: TransactionAdapter
        adapter = TransactionAdapter(
            emptyList(),
            onDeleteClick = { entry ->
                AlertDialog.Builder(requireContext())
                    .setTitle("এন্ট্রি মুছে ফেলুন?")
                    .setMessage("${entry.shopName} — ₹${entry.transaction.totalAmount} মুছে ফেলতে চান?")
                    .setPositiveButton("হ্যাঁ, মুছুন") { _, _ ->
                        viewLifecycleOwner.lifecycleScope.launch {
                            dao.deleteTransactionWithItems(entry.transaction)
                            Toast.makeText(context, "এন্ট্রি মুছে ফেলা হয়েছে", Toast.LENGTH_SHORT).show()
                        }
                    }
                    .setNegativeButton("বাতিল", null)
                    .show()
            },
            // নিরাপত্তার জন্য: শুধুমাত্র আজকের তারিখের এন্ট্রি মুছে ফেলার অনুমতি
            canDelete = { entry -> entry.transaction.dateString == todayStr },
            onItemClick = { entry -> showDetailDialog(entry) }
        )
        rv.adapter = adapter

        fun applyFilter() {
            val query = etSearch.text.toString()
            var filtered = allTransactions
            if (typeFilter != null) {
                filtered = filtered.filter { it.transaction.type == typeFilter }
            }
            if (query.isNotBlank()) {
                filtered = filtered.filter { it.shopName.contains(query, ignoreCase = true) }
            }
            adapter.updateList(filtered)
        }

        fun setActiveButton(active: Button) {
            listOf(btnAll, btnCredit, btnPayment).forEach {
                it.setBackgroundColor(resources.getColor(R.color.bg_light, null))
                it.setTextColor(resources.getColor(R.color.text_dark, null))
            }
            active.setBackgroundColor(resources.getColor(R.color.deep_navy, null))
            active.setTextColor(resources.getColor(R.color.white, null))
        }

        btnAll.setOnClickListener { typeFilter = null; setActiveButton(btnAll); applyFilter() }
        btnCredit.setOnClickListener { typeFilter = "CREDIT"; setActiveButton(btnCredit); applyFilter() }
        btnPayment.setOnClickListener { typeFilter = "PAYMENT"; setActiveButton(btnPayment); applyFilter() }

        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) { applyFilter() }
        })

        viewLifecycleOwner.lifecycleScope.launch {
            dao.getAllTransactionsWithShop().collect {
                allTransactions = it
                applyFilter()
            }
        }
    }
}
