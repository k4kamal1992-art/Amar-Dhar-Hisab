package com.amardhar.hisab.ui.fragments

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.amardhar.hisab.AmarDharApp
import com.amardhar.hisab.R
import com.amardhar.hisab.ui.adapters.TransactionAdapter
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch

class HistoryFragment : Fragment(R.layout.fragment_history) {
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        val rv = view.findViewById<RecyclerView>(R.id.rv_history)
        rv.layoutManager = LinearLayoutManager(context)
        val adapter = TransactionAdapter(emptyList())
        rv.adapter = adapter

        val app = requireActivity().application as AmarDharApp
        MainScope().launch {
            app.database.appDao().getAllTransactions().collect { 
                adapter.updateList(it)
            }
        }
    }
}