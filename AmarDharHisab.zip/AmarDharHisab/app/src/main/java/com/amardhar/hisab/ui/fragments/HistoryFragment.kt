package com.amardhar.hisab.ui.fragments

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.amardhar.hisab.AmarDharApp
import com.amardhar.hisab.R
import com.amardhar.hisab.data.TransactionWithShop
import com.amardhar.hisab.ui.adapters.TransactionAdapter
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HistoryFragment : Fragment(R.layout.fragment_history) {

    private var allTransactions: List<TransactionWithShop> = emptyList()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val app = requireActivity().application as AmarDharApp
        val dao = app.database.appDao()
        val todayStr = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(Date())

        val rv = view.findViewById<RecyclerView>(R.id.rv_history)
        rv.layoutManager = LinearLayoutManager(context)
        val etSearch = view.findViewById<EditText>(R.id.et_search_history)

        lateinit var adapter: TransactionAdapter
        adapter = TransactionAdapter(
            emptyList(),
            onDeleteClick = { entry ->
                AlertDialog.Builder(requireContext())
                    .setTitle("এন্ট্রি মুছে ফেলুন?")
                    .setMessage("${entry.shopName} — ₹${entry.transaction.totalAmount} মুছে ফেলতে চান?")
                    .setPositiveButton("হ্যাঁ, মুছুন") { _, _ ->
                        viewLifecycleOwner.lifecycleScope.launch {
                            dao.deleteTransactionWithItems(entry.transaction)
                            Toast.makeText(context, "এন্ট্রি মুছে ফেলা হয়েছে", Toast.LENGTH_SHORT).show()
                        }
                    }
                    .setNegativeButton("বাতিল", null)
                    .show()
            },
            // নিরাপত্তার জন্য: শুধুমাত্র আজকের তারিখের এন্ট্রি মুছে ফেলার অনুমতি
            canDelete = { entry -> entry.transaction.dateString == todayStr }
        )
        rv.adapter = adapter

        fun applyFilter(query: String) {
            val filtered = if (query.isBlank()) {
                allTransactions
            } else {
                allTransactions.filter { it.shopName.contains(query, ignoreCase = true) }
            }
            adapter.updateList(filtered)
        }

        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) { applyFilter(s.toString()) }
        })

        viewLifecycleOwner.lifecycleScope.launch {
            dao.getAllTransactionsWithShop().collect {
                allTransactions = it
                applyFilter(etSearch.text.toString())
            }
        }
    }
}
