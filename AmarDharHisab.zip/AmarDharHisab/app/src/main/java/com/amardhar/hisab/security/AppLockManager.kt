package com.amardhar.hisab.security

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.security.SecureRandom
import java.security.spec.KeySpec
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/**
 * PIN নিরাপত্তা ব্যবস্থাপক।
 * PIN কখনো প্লেইন টেক্সটে সংরক্ষণ করা হয় না — salt + PBKDF2 হ্যাশ আকারে রাখা হয়।
 * বারবার ভুল PIN দিলে সাময়িক Lockout প্রয়োগ করা হয়।
 */
class AppLockManager(context: Context) {

    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs = EncryptedSharedPreferences.create(
        context,
        "secret_shared_prefs",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    companion object {
        private const val KEY_HASH = "pin_hash"
        private const val KEY_SALT = "pin_salt"
        private const val KEY_BIOMETRIC = "biometric_enabled"
        private const val KEY_FAILED_ATTEMPTS = "failed_attempts"
        private const val KEY_LOCKOUT_UNTIL = "lockout_until"
        private const val ITERATIONS = 10000
        private const val KEY_LENGTH = 256

        // পরপর এতবার ভুল হলে সাময়িক লকআউট শুরু হবে
        private const val MAX_ATTEMPTS = 5
        private const val LOCKOUT_DURATION_MS = 60_000L // ১ মিনিট
    }

    private fun hashPin(pin: String, salt: ByteArray): String {
        val spec: KeySpec = PBEKeySpec(pin.toCharArray(), salt, ITERATIONS, KEY_LENGTH)
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val hash = factory.generateSecret(spec).encoded
        return hash.joinToString("") { "%02x".format(it) }
    }

    fun hasPin(): Boolean = prefs.getString(KEY_HASH, null) != null

    fun setPin(pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val hash = hashPin(pin, salt)
        prefs.edit()
            .putString(KEY_HASH, hash)
            .putString(KEY_SALT, salt.joinToString(",") { it.toString() })
            .putInt(KEY_FAILED_ATTEMPTS, 0)
            .putLong(KEY_LOCKOUT_UNTIL, 0)
            .apply()
    }

    fun clearPin() {
        prefs.edit().clear().apply()
    }

    /**
     * PIN সঠিক হলে true রিটার্ন করে। ভুল হলে failed attempt বাড়ায় এবং
     * প্রয়োজনে lockout সময় সেট করে।
     */
    fun verifyPin(pin: String): Boolean {
        val storedHash = prefs.getString(KEY_HASH, null) ?: return false
        val saltStr = prefs.getString(KEY_SALT, null) ?: return false
        val salt = saltStr.split(",").map { it.toByte() }.toByteArray()
        val inputHash = hashPin(pin, salt)

        return if (inputHash == storedHash) {
            prefs.edit().putInt(KEY_FAILED_ATTEMPTS, 0).putLong(KEY_LOCKOUT_UNTIL, 0).apply()
            true
        } else {
            val attempts = prefs.getInt(KEY_FAILED_ATTEMPTS, 0) + 1
            val editor = prefs.edit().putInt(KEY_FAILED_ATTEMPTS, attempts)
            if (attempts >= MAX_ATTEMPTS) {
                editor.putLong(KEY_LOCKOUT_UNTIL, System.currentTimeMillis() + LOCKOUT_DURATION_MS)
                editor.putInt(KEY_FAILED_ATTEMPTS, 0)
            }
            editor.apply()
            false
        }
    }

    /** এখনো লকআউট চললে বাকি সময় (মিলিসেকেন্ড) রিটার্ন করে, নাহলে 0 */
    fun getLockoutRemainingMs(): Long {
        val until = prefs.getLong(KEY_LOCKOUT_UNTIL, 0)
        val remaining = until - System.currentTimeMillis()
        return if (remaining > 0) remaining else 0
    }

    fun setBiometricEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_BIOMETRIC, enabled).apply()
    }

    fun isBiometricEnabled(): Boolean = prefs.getBoolean(KEY_BIOMETRIC, false)
}
