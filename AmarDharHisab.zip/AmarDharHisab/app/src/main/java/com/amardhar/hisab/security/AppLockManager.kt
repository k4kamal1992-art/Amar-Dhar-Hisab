package com.amardhar.hisab.security

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

class AppLockManager(context: Context) {
    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val sharedPreferences = EncryptedSharedPreferences.create(
        context,
        "secret_shared_prefs",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun setPIN(pin: String) {
        sharedPreferences.edit().putString("app_pin", pin).apply()
    }

    fun getPIN(): String? {
        return sharedPreferences.getString("app_pin", null)
    }

    fun isLocked(): Boolean {
        return getPIN() != null
    }
}