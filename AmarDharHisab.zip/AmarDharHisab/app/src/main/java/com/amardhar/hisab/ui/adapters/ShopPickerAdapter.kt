package com.amardhar.hisab.ui.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.amardhar.hisab.R
import com.amardhar.hisab.data.Shop
import com.amardhar.hisab.utils.IconMapper

class ShopPickerAdapter(
    private var list: List<Shop>,
    private val onClick: (Shop) -> Unit
) : RecyclerView.Adapter<ShopPickerAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.iv_picker_shop_icon)
        val name: TextView = view.findViewById(R.id.tv_picker_shop_name)
        val owner: TextView = view.findViewById(R.id.tv_picker_owner_name)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_shop_picker, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val shop = list[position]
        holder.icon.setImageResource(IconMapper.getShopIcon(shop.name))
        holder.name.text = shop.name
        holder.owner.text = shop.ownerName
        holder.itemView.setOnClickListener { onClick(shop) }
    }

    override fun getItemCount() = list.size

    fun updateList(newList: List<Shop>) {
        list = newList
        notifyDataSetChanged()
    }
}
