package com.amardhar.hisab.utils

import com.amardhar.hisab.data.AppDao
import com.amardhar.hisab.data.BackupPayload
import com.google.gson.Gson
import com.google.gson.GsonBuilder

object BackupManager {

    private val gson: Gson = GsonBuilder().setPrettyPrinting().create()

    suspend fun exportToJson(dao: AppDao): String {
        val payload = BackupPayload(
            shops = dao.getAllShopsSnapshot(),
            products = dao.getAllProductsSnapshot(),
            transactions = dao.getAllTransactionsSnapshot(),
            transactionItems = dao.getAllTransactionItemsSnapshot(),
            priceHistory = dao.getAllPriceHistorySnapshot()
        )
        return gson.toJson(payload)
    }

    /**
     * @return সফল হলে null, ব্যর্থ হলে এরর মেসেজ
     */
    suspend fun importFromJson(json: String, dao: AppDao): String? {
        return try {
            val payload = gson.fromJson(json, BackupPayload::class.java)
                ?: return "ব্যাকআপ ফাইলটি সঠিক ফরম্যাটে নেই"
            dao.restoreAll(payload)
            null
        } catch (e: Exception) {
            "রিস্টোর ব্যর্থ হয়েছে: ${e.message}"
        }
    }
}
