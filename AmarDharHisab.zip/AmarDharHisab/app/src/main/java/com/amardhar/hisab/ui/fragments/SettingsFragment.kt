package com.amardhar.hisab.ui.fragments

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.amardhar.hisab.AmarDharApp
import com.amardhar.hisab.R
import com.amardhar.hisab.data.Shop
import com.amardhar.hisab.security.AppLockManager
import com.amardhar.hisab.ui.LockActivity
import com.amardhar.hisab.utils.BackupManager
import com.amardhar.hisab.utils.PdfReportGenerator
import kotlinx.coroutines.launch

class SettingsFragment : Fragment(R.layout.fragment_settings) {

    private lateinit var lockManager: AppLockManager
    private var selectedShopForPdf: Shop? = null

    private val createBackupLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri == null) return@registerForActivityResult
        val app = requireActivity().application as AmarDharApp
        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val json = BackupManager.exportToJson(app.database.appDao())
                requireContext().contentResolver.openOutputStream(uri)?.use { it.write(json.toByteArray()) }
                Toast.makeText(context, "ব্যাকআপ সফলভাবে সেভ হয়েছে", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(context, "ব্যাকআপ ব্যর্থ হয়েছে: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private val openRestoreLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@registerForActivityResult
        val app = requireActivity().application as AmarDharApp
        AlertDialog.Builder(requireContext())
            .setTitle("রিস্টোর করবেন?")
            .setMessage("এটি আপনার বর্তমান সব ডেটা মুছে ব্যাকআপ ফাইলের ডেটা দিয়ে প্রতিস্থাপন করবে। আপনি কি নিশ্চিত?")
            .setPositiveButton("হ্যাঁ, রিস্টোর করুন") { _, _ ->
                viewLifecycleOwner.lifecycleScope.launch {
                    try {
                        val json = requireContext().contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                        if (json == null) {
                            Toast.makeText(context, "ফাইল পড়া যায়নি", Toast.LENGTH_SHORT).show()
                            return@launch
                        }
                        val error = BackupManager.importFromJson(json, app.database.appDao())
                        if (error == null) {
                            Toast.makeText(context, "রিস্টোর সফল হয়েছে!", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(context, error, Toast.LENGTH_LONG).show()
                        }
                    } catch (e: Exception) {
                        Toast.makeText(context, "রিস্টোর ব্যর্থ হয়েছে: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
            .setNegativeButton("বাতিল", null)
            .show()
    }

    private val createPdfLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri == null || selectedShopForPdf == null) return@registerForActivityResult
        val app = requireActivity().application as AmarDharApp
        val shop = selectedShopForPdf!!
        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val transactions = kotlinx.coroutines.flow.first(app.database.appDao().getAllTransactionsWithShop())
                    .filter { it.transaction.shopId == shop.id }

                requireContext().contentResolver.openOutputStream(uri)?.use { out ->
                    PdfReportGenerator.generate(shop, transactions, out)
                }
                Toast.makeText(context, "PDF রিপোর্ট তৈরি হয়েছে", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(context, "PDF তৈরি ব্যর্থ হয়েছে: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        lockManager = AppLockManager(requireContext())
        val app = requireActivity().application as AmarDharApp
        val dao = app.database.appDao()

        val tvPinTitle = view.findViewById<TextView>(R.id.tv_pin_row_title)
        val switchBiometric = view.findViewById<Switch>(R.id.switch_biometric)

        fun refreshPinRow() {
            tvPinTitle.text = if (lockManager.hasPin()) "PIN পরিবর্তন করুন" else "PIN সেট করুন"
            switchBiometric.isEnabled = lockManager.hasPin()
            switchBiometric.isChecked = lockManager.isBiometricEnabled()
        }
        refreshPinRow()

        view.findViewById<View>(R.id.row_pin).setOnClickListener {
            val intent = Intent(requireContext(), LockActivity::class.java)
            intent.putExtra("setup_mode", true)
            startActivity(intent)
        }

        switchBiometric.setOnCheckedChangeListener { _, isChecked ->
            if (!lockManager.hasPin() && isChecked) {
                Toast.makeText(context, "প্রথমে একটি PIN সেট করুন", Toast.LENGTH_SHORT).show()
                switchBiometric.isChecked = false
                return@setOnCheckedChangeListener
            }
            lockManager.setBiometricEnabled(isChecked)
        }

        view.findViewById<View>(R.id.row_backup).setOnClickListener {
            createBackupLauncher.launch("amardhar_backup.json")
        }

        view.findViewById<View>(R.id.row_restore).setOnClickListener {
            openRestoreLauncher.launch(arrayOf("application/json"))
        }

        view.findViewById<View>(R.id.row_pdf).setOnClickListener {
            viewLifecycleOwner.lifecycleScope.launch {
                val shops = kotlinx.coroutines.flow.first(dao.getAllShops())
                if (shops.isEmpty()) {
                    Toast.makeText(context, "কোনো দোকান নেই", Toast.LENGTH_SHORT).show()
                    return@launch
                }
                val names = shops.map { it.name }.toTypedArray()
                AlertDialog.Builder(requireContext())
                    .setTitle("কোন দোকানের রিপোর্ট চান?")
                    .setItems(names) { _, which ->
                        selectedShopForPdf = shops[which]
                        createPdfLauncher.launch("${shops[which].name}_hisab.pdf")
                    }
                    .show()
            }
        }

        view.findViewById<View>(R.id.row_analytics).setOnClickListener {
            findNavController().navigate(R.id.action_nav_settings_to_analytics)
        }
    }

    override fun onResume() {
        super.onResume()
        // PIN সেটআপ থেকে ফিরে এলে রো টাইটেল ও সুইচের অবস্থা রিফ্রেশ করা
        if (::lockManager.isInitialized) {
            val tvPinTitle = view?.findViewById<TextView>(R.id.tv_pin_row_title)
            val switchBiometric = view?.findViewById<Switch>(R.id.switch_biometric)
            tvPinTitle?.text = if (lockManager.hasPin()) "PIN পরিবর্তন করুন" else "PIN সেট করুন"
            switchBiometric?.isEnabled = lockManager.hasPin()
            switchBiometric?.isChecked = lockManager.isBiometricEnabled()
        }
    }
}
