package com.amardhar.hisab.ui.fragments
import androidx.fragment.app.Fragment
import com.amardhar.hisab.R
class SettingsFragment : Fragment(R.layout.fragment_settings)