package com.amardhar.hisab.data

import androidx.room.ColumnInfo
import androidx.room.Embedded

/**
 * একটি দোকানের সারসংক্ষেপ — মোট ধার, মোট পরিশোধ ও বর্তমান বাকি
 */
data class ShopSummary(
    @ColumnInfo(name = "shopId") val shopId: Long,
    @ColumnInfo(name = "shopName") val shopName: String,
    @ColumnInfo(name = "ownerName") val ownerName: String,
    @ColumnInfo(name = "totalCredit") val totalCredit: Double,
    @ColumnInfo(name = "totalPayment") val totalPayment: Double
) {
    val due: Double
        get() = totalCredit - totalPayment
}

/**
 * একটি লেনদেন, দোকানের নাম সহ (History ও Home স্ক্রিনে দেখানোর জন্য)
 */
data class TransactionWithShop(
    @Embedded val transaction: Transaction,
    @ColumnInfo(name = "shopName") val shopName: String
)
