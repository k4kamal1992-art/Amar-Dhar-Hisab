package com.amardhar.hisab.ui.adapters

import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.amardhar.hisab.R
import com.amardhar.hisab.data.Product

/**
 * Quick Entry স্ক্রিনে পণ্য নির্বাচনের জন্য অ্যাডাপ্টার।
 * প্রতিটি পণ্যের জন্য quantity ইনপুট নেওয়া হয়, subtotal লাইভ হিসাব হয়,
 * এবং onTotalChanged কলব্যাকের মাধ্যমে সম্পূর্ণ মোট পরিমাণ ফ্র্যাগমেন্টে জানানো হয়।
 */
class QuickEntryProductAdapter(
    private val products: List<Product>,
    private val onTotalChanged: (total: Double) -> Unit
) : RecyclerView.Adapter<QuickEntryProductAdapter.ViewHolder>() {

    // productId -> quantity
    private val quantities = mutableMapOf<Long, Double>()

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val name: TextView = view.findViewById(R.id.tv_qe_product_name)
        val unitPrice: TextView = view.findViewById(R.id.tv_qe_unit_price)
        val quantityInput: EditText = view.findViewById(R.id.et_qe_quantity)
        val subtotal: TextView = view.findViewById(R.id.tv_qe_subtotal)
        var watcher: TextWatcher? = null
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_quick_entry_product, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val product = products[position]
        holder.name.text = product.name
        holder.unitPrice.text = "একক দাম: ₹${product.price}"

        // আগের watcher সরিয়ে নেওয়া (RecyclerView রিসাইকেলের কারণে ভুল কলব্যাক এড়াতে)
        holder.watcher?.let { holder.quantityInput.removeTextChangedListener(it) }

        val currentQty = quantities[product.id]
        holder.quantityInput.setText(if (currentQty != null && currentQty > 0) currentQty.toString() else "")
        holder.subtotal.text = "₹${(currentQty ?: 0.0) * product.price}"

        val watcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val qty = s.toString().toDoubleOrNull() ?: 0.0
                quantities[product.id] = qty
                holder.subtotal.text = "₹${qty * product.price}"
                onTotalChanged(calculateTotal())
            }
        }
        holder.quantityInput.addTextChangedListener(watcher)
        holder.watcher = watcher
    }

    override fun getItemCount() = products.size

    private fun calculateTotal(): Double {
        var total = 0.0
        products.forEach { p ->
            val qty = quantities[p.id] ?: 0.0
            total += qty * p.price
        }
        return total
    }

    /**
     * শুধুমাত্র যেসব পণ্যে quantity > 0 দেওয়া হয়েছে, তাদের তালিকা রিটার্ন করে (নাম, দাম, পরিমাণ, সাবটোটাল সহ)।
     */
    fun getSelectedItems(): List<SelectedProduct> {
        return products.mapNotNull { p ->
            val qty = quantities[p.id] ?: 0.0
            if (qty > 0) SelectedProduct(p.id, p.name, p.price, qty, qty * p.price) else null
        }
    }

    data class SelectedProduct(
        val productId: Long,
        val name: String,
        val unitPrice: Double,
        val quantity: Double,
        val subtotal: Double
    )
}
