package com.amardhar.hisab.ui.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.navArgs
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.amardhar.hisab.AmarDharApp
import com.amardhar.hisab.R
import com.amardhar.hisab.data.AppDao
import com.amardhar.hisab.data.Product
import com.amardhar.hisab.ui.adapters.ProductAdapter
import com.google.android.material.floatingactionbutton.FloatingActionButton
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ShopDetailFragment : Fragment(R.layout.fragment_shop_detail) {

    private val args: ShopDetailFragmentArgs by navArgs()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val app = requireActivity().application as AmarDharApp
        val dao = app.database.appDao()
        val shopId = args.shopId

        view.findViewById<TextView>(R.id.tv_detail_shop_name).text = args.shopName

        val rv = view.findViewById<RecyclerView>(R.id.rv_products)
        rv.layoutManager = LinearLayoutManager(context)
        val adapter = ProductAdapter(
            emptyList(),
            onDeleteClick = { product ->
                viewLifecycleOwner.lifecycleScope.launch {
                    dao.deleteProduct(product)
                    Toast.makeText(context, "পণ্য মুছে ফেলা হয়েছে", Toast.LENGTH_SHORT).show()
                }
            }
        )
        rv.adapter = adapter

        viewLifecycleOwner.lifecycleScope.launch {
            dao.getProductsByShop(shopId).collect { adapter.updateList(it) }
        }

        val fab = view.findViewById<FloatingActionButton>(R.id.fab_add_product)
        fab.setOnClickListener { showAddProductDialog(dao, shopId) }
    }

    private fun showAddProductDialog(dao: AppDao, shopId: Long) {
        val dialogView = LayoutInflater.from(context).inflate(R.layout.dialog_add_product, null)
        val etName = dialogView.findViewById<EditText>(R.id.et_dialog_product_name)
        val etPrice = dialogView.findViewById<EditText>(R.id.et_dialog_product_price)

        AlertDialog.Builder(requireContext())
            .setTitle("নতুন পণ্য যোগ করুন")
            .setView(dialogView)
            .setPositiveButton("সেভ করুন") { _, _ ->
                val name = etName.text.toString().trim()
                val price = etPrice.text.toString().toDoubleOrNull()
                if (name.isEmpty() || price == null) {
                    Toast.makeText(context, "সঠিক নাম ও দাম দিন", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                viewLifecycleOwner.lifecycleScope.launch {
                    val date = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(Date())
                    dao.insertProduct(Product(shopId = shopId, name = name, price = price), date)
                    Toast.makeText(context, "পণ্য যোগ হয়েছে", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("বাতিল", null)
            .show()
    }
}
